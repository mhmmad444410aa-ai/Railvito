const {spawn}=require('child_process');
const fs=require('fs');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const port=8779;
fs.mkdirSync('build/world-shots',{recursive:true});
(async()=>{
 const srv=spawn('python3',['-u','-m','http.server',String(port),'--bind','127.0.0.1','--directory','build/web']);
 await new Promise(r=>srv.stdout.once('data',r));
 const browser=await chromium.launch({executablePath:process.env.RAILVITO_CHROMIUM_PATH || chromium.executablePath(),headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader','--use-angle=swiftshader','--disable-dev-shm-usage']});
 const errors=[];
 try{
  const page=await browser.newPage({viewport:{width:1280,height:720}});
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  const click=(x,y)=>page.mouse.click(x,y);
  const snap=()=>page.evaluate(()=>window.railvitoSnapshot);
  const state=(screen,level)=>page.waitForFunction(([s,i])=>window.railvitoSnapshot?.screen===s&&(i==null||window.railvitoSnapshot.level===i),[screen,level],{timeout:20000});
  await page.goto('http://localhost:'+port);
  await state('menu');
  await click(202,529);
  await state('worlds');
  await page.screenshot({path:'build/world-shots/00-world-select.png'});
  const names=['river','summit','sky','town'];
  for(let i=0;i<4;i++){
   await click(220+(i%3)*400,290+Math.floor(i/3)*245);
   await state('levels');
   await click(340,553);
   await state('game',10+i*2);
   await page.waitForTimeout(1600);
   await page.screenshot({path:'build/world-shots/0'+(i+1)+'-'+names[i]+'.png'});
   console.log('CAPTURED',names[i],await snap());
   if(i===0 || i===2){
    for(const gap of (await snap()).missing){
     if((await snap()).selected_yaw%180!==gap.yaw%180){
      await click(390,628);
      await page.waitForFunction(angle=>window.railvitoSnapshot.selected_yaw%180===angle,gap.yaw%180);
     }
     await page.mouse.move(94,626);
     await page.mouse.down();
     await page.mouse.move(gap.x,gap.y,{steps:8});
     await page.mouse.up();
     await page.waitForFunction(idx=>!window.railvitoSnapshot.missing.some(g=>g.index===idx),gap.index,{timeout:9000});
    }
    await click(985,629);
    await page.waitForFunction(()=>window.railvitoSnapshot.speed>0.3,null,{timeout:7000});
    if(i===0){
     await click(1235,673);
     await page.waitForFunction(()=>window.railvitoSnapshot.won,null,{timeout:60000});
     console.log('RIVER_INTERACTIVE_VICTORY');
     await click(625,508);
     await state('game',10);
    }
   }
   if(i===3){
    await click(325,628);
    await click(595,650);
    await page.waitForFunction(()=>window.railvitoSnapshot.branch===0 && window.railvitoSnapshot.cargo===2,null,{timeout:10000});
    await click(1235,673);
    await click(985,629);
    await page.waitForFunction(()=>{let s=window.railvitoSnapshot;return s.speed>=0.5 && s.goal-s.distance<2.5;},null,{timeout:65000});
    await click(1170,628);
    await page.waitForFunction(()=>window.railvitoSnapshot.won,null,{timeout:12000});
    console.log('CITY_INTERACTIVE_VICTORY');
    await page.waitForTimeout(7200);await page.reload();await state('menu');
    console.log('STARS_AFTER_RELOAD',(await snap()).stars);
    await page.waitForFunction(()=>window.railvitoSnapshot.stars[10]>0 && window.railvitoSnapshot.stars[16]>0);
    console.log('STARS_PERSIST');
    break;
   }
   await click(64,56);
   await state('levels');
   await click(104,53);
   await state('worlds');
  }
  if(errors.length)throw Error(errors.join('\n'));
  fs.writeFileSync('build/world-browser-results.json',JSON.stringify({passed:true,errors,verified:'Four worlds; bridge drags on varied terrain; river and city wins; city routing and cargo; reload'}));
 } catch(e){console.error('Browser errors:',errors);throw e;}
 finally{await browser.close();srv.kill();}
})().catch(e=>{console.error(e);process.exitCode=1;});
