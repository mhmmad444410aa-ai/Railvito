All other files in this directory are historical test evidence for 1.1.0. No Godot tests for 1.2.0 were run in this environment. See docs/UPDATE_1.2.0.md.
