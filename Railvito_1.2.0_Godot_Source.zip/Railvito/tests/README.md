Native checks from the project root:

- `godot --headless -- --self-test`
- `godot --headless --script res://tests/verify_engines.gd`
- `XDG_DATA_HOME=/tmp/railvito-1-1-test godot --headless --script res://tests/verify_worlds.gd`
- `python3 tools/verify_assets.py`

Use an isolated data directory for the world test because it writes a sample
legacy save to exercise migration. For browser checks, export the Web preset into
`build/web/index.html`, install Playwright and a Chromium browser, then run
`node tests/browser_worlds.cjs` from the root. `RAILVITO_CHROMIUM_PATH` optionally
selects an existing Chromium executable. The script also captures four scenes.

## 1.2.0 cab smoke test (not yet executed)

`godot --headless --script res://tests/verify_cab.gd` checks cab presence, speed cycling, bell state, braking and horizon across all missions. Headless uses 2D fallback icons; visual 3D rendering requires a graphical run.
