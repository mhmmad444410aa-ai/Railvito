extends SceneTree

const Network = preload("res://scripts/rail_network.gd")

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var game = load("res://scenes/main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.set_process(false)
	var identities: Dictionary = {}
	for mission in Network.levels().slice(10):
		game._start_level(mission.id)
		var route: Dictionary = game.route
		assert(route.open and route.length>27 and route.pieces.size()>7)
		var signature := str(route.points)+"-"+str(mission.station)
		assert(not identities.has(signature),"Each new mission must change its itinerary")
		identities[signature]=true
		assert(game.art.stations.size()==(3 if mission.world==5 else 2))
		if mission.mode=="build":
			assert(game.missing.size()==2)
			game._go()
			assert(game.desired_speed==0,"An incomplete bridge must block departure")
			for idx in game.missing.duplicate():
				game.selected_kind="straight"
				assert(not game._place_piece(idx))
				game.selected_kind="bridge"
				game.selected_yaw=posmod(roundi(rad_to_deg(route.pieces[idx].yaw)),180)
				assert(game._place_piece(idx))
			game._undo()
			assert(game.missing.size()==1)
			game._redo()
			assert(game.missing.is_empty())
		if mission.world==5:
			assert(game.switch_index!=mission.station and game.goal_distance<0)
			game._set_switch(mission.station)
			assert(game.route.branch==mission.station and game.goal_distance>0)
		if mission.mode=="cargo":
			game._load_cargo(1)
			game._go()
			assert(game.desired_speed==0,"Wrong cargo cannot depart")
			game._load_cargo(mission.number)
		game.speed_setting=4.3
		game._go()
		var last_distance: float=game.distance
		var braked:=false
		for frame in range(1500):
			if mission.mode!="build" and not braked and game.distance>=float(game.goal_distance)-1.9:
				game._brake()
				braked=true
			game._process(1.0/30.0)
			assert(game.distance>=last_distance and game.distance<game.route.length)
			last_distance=game.distance
			for car in game.cars:
				assert(car.position.is_finite())
			if game.won:
				break
		assert(game.won,"Completable new mission: "+str(mission.id))
		assert(game.stars[mission.id]==3)
		print("MISSION_PASS ",mission.id+1)
		await process_frame
	game._start_level(16)
	game._load_cargo(2)
	game._go()
	for frame in range(1500):
		game._process(1.0/30.0)
	assert(not game.won,"Wrong city branch never awards stars")
	assert(game.distance>game.route.length-0.7 and game.speed==0.0)
	var old_save:=ConfigFile.new()
	old_save.set_value("state","stars",[3,2,0,3,1,0,0,0,0,0])
	old_save.save(game.SAVE_PATH)
	game.stars.fill(0)
	game._load_save()
	assert(game.stars.size()==18 and game.stars[0]==3 and game.stars[4]==1 and game.stars[17]==0)
	print("WORLD_EXPANSION_PASS 8 missions; blocked incomplete bridges; wrong branches; original save migration")
	game.queue_free()
	await process_frame
	quit()
