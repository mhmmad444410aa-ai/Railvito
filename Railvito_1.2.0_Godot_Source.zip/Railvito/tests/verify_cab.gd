extends SceneTree
const Network = preload("res://scripts/rail_network.gd")
const Words = preload("res://scripts/strings.gd")

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var game = load("res://scenes/main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.set_process(false)
	for mission in Network.levels():
		game._start_level(mission.id)
		assert(game.ui.find_child("CabBell",true,false)!=null)
		assert(game.ui.find_child("CabBrake",true,false)!=null)
		assert(game.ui.find_child("CabLever",true,false)!=null)
		assert(game.world.get_node_or_null("ScenicHorizon")!=null)
		var previous: int=game.bell_count
		game._ring_bell()
		assert(game.bell_count==previous+1)
		game.speed_slider.value=1.4
		game._cycle_speed()
		assert(is_equal_approx(game.speed_setting,2.8))
		game._cycle_speed()
		assert(is_equal_approx(game.speed_setting,4.8))
		game._cycle_speed()
		assert(is_equal_approx(game.speed_setting,1.4))
		game.desired_speed=2.8
		game._brake()
		assert(game.desired_speed==0 and game.brake_requested)
		await process_frame
	for lang in ["en_GB","ar","pt_BR"]:
		assert(Words.get_text("bell",lang)!="bell")
		assert(Words.get_text("speed_lever",lang)!="speed_lever")
	print("CAB_CHECK_OK: all 18 missions, bell, brake, speed cycling, horizon and translations")
	game.queue_free()
	await process_frame
	quit()
