extends SceneTree

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var scene=load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	await process_frame
	for i in range(3):
		scene.train_choice=i
		scene._create_train()
		assert(scene.cars.size()==3,"Each engine needs both carriages")
		assert(scene.wheels.size()>=2,"Wheel/bogie meshes must load")
		for d in [0.0,2.0,10.0,20.0,40.0,52.5]:
			scene.distance=d;scene._update_train(0.1)
			for car in scene.cars:assert(car.position.is_finite() and car.rotation.is_finite())
		scene._start_level(0)
		scene._go()
		assert(scene.desired_speed==0,"An incomplete railway must block departure")
	print("ENGINE_CHECK_OK: all 3 engines, both carriages, wheel nodes, curve samples and incomplete-route blocking")
	for lang in ["en_GB","ar","pt_BR"]:
		scene.language=lang
		scene._game_ui();scene._parents_gate();scene._parents_area();scene._privacy();scene._about();scene._close_modal()
	print("PARENTS_CHECK_OK: gate, local privacy and license views constructed in all 3 languages")
	scene._toast("A temporary hint")
	scene._start_level(1)
	await create_timer(3.2).timeout
	print("TOAST_LIFETIME_CHECK_OK: changing levels before a hint expires")
	scene.queue_free()
	await process_frame
	quit(0)
