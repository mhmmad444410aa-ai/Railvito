const {spawn}=require('child_process');
const fs=require('fs');const assert=require('assert');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const srv=spawn('python3',['-u','-m','http.server','8768','--bind','127.0.0.1','--directory','build/web']);
 await new Promise(r=>srv.stdout.once('data',r));
 const browser=await chromium.launch({executablePath:process.env.RAILVITO_CHROMIUM_PATH || chromium.executablePath(),headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader','--use-angle=swiftshader','--disable-dev-shm-usage']});
 const errors=[];const results=[];let monitor;
 try {
  const context=await browser.newContext({viewport:{width:1280,height:720}});
  const page=await context.newPage();
  page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
  page.on('pageerror',e=>errors.push(e.message));
  const state=()=>page.evaluate(()=>window.railvitoSnapshot); monitor=setInterval(async()=>{try{console.log('STATE',JSON.stringify(await state()))}catch{}},10000);
  const click=async(x,y)=>{const lang=await page.evaluate(()=>window.railvitoSnapshot?.language);await page.mouse.click(lang==='ar'?1280-x:x,y);await pause(500)};
  const shot=async n=>page.screenshot({path:'build/'+n+'.png'});
  await page.goto('http://127.0.0.1:8768');await page.waitForFunction(()=>window.railvitoSnapshot?.screen==='menu',null,{timeout:90000});
  await shot('01-menu');
   await click(200,529);
   await page.waitForFunction(()=>window.railvitoSnapshot?.screen==='worlds');
   await click(620,535);
   await page.waitForFunction(()=>window.railvitoSnapshot?.screen==='levels');
   await click(205,553);
  await page.waitForFunction(()=>window.railvitoSnapshot?.screen==='game');
  await shot('02-builder');
  // A wrong direction must be rejected through the real controls.
  let s=await state();let g=s.missing.find(x=>x.kind==='straight');
  await click(g.x,g.y);assert.equal((await state()).missing.length,s.missing.length);
  results.push('Invalid rotation rejected');
  for(let level=0;level<10;level++){
   await page.waitForFunction(l=>window.railvitoSnapshot?.level===l && !window.railvitoSnapshot?.won,level,{timeout:15000});
   s=await state();
   while(s.missing.length){
    g=s.missing[0];
    let target=g.yaw;
    while((await state()).selected_yaw!==target){await click(386,628);await pause(300)}
    const x=g.kind==='straight'?103:246;
    await page.mouse.move(x,628);await page.mouse.down();await page.mouse.move(g.x,g.y,{steps:14});await page.mouse.up();
    const count=s.missing.length-1;
    await page.waitForFunction(n=>window.railvitoSnapshot.missing.length===n,count,{timeout:6000});
    s=await state();
   }
   if(level===0){
    await click(514,628);await page.waitForFunction(()=>window.railvitoSnapshot.missing.length===1,null,{timeout:7000});
    await click(642,628);await page.waitForFunction(()=>window.railvitoSnapshot.missing.length===0,null,{timeout:7000});results.push('Undo and redo via buttons');
   }
   const cargo={3:2,7:3,9:4}[level];
   if(cargo){await click(248+(cargo-1)*80,628);await page.waitForFunction(n=>window.railvitoSnapshot.cargo===n,cargo,{timeout:7000})}
   // Set the speed slider using pointer input, then start the train.
   await click(1237,675);await click(993,628);
   if(level===0){await pause(700);await shot('03-train-running')}
   if(![0,1,4,5,8].includes(level)){
    await page.waitForFunction(()=>{const s=window.railvitoSnapshot;const len=52.565;let remaining=(s.goal-s.distance+len)%len;return s.speed>1 && remaining<Math.max(2.0,s.speed*s.speed/9.6+0.65)},null,{timeout:60000});
    await click(1164,628);
   }
   await page.waitForFunction(()=>window.railvitoSnapshot?.won,null,{timeout:60000});
   assert.equal((await state()).stars[level],3);
   console.log('PASS adventure',level+1);results.push('Adventure '+(level+1)+' completed via pointer controls');
   if(level===0)await shot('04-victory');
   if(level<9){await click(640,429);await pause(450)}
   if(level===4)await shot('05-waterfall-world');
   if(level===6)await shot('06-count-deliver');
  }
  await page.reload();await page.waitForFunction(()=>window.railvitoSnapshot?.screen==='menu',null,{timeout:90000});
  assert.equal((await state()).stars.reduce((a,b)=>a+b,0),30);results.push('All 30 stars persisted after page reload');
  // Settings and RTL, using visible controls.
  await click(385,650);await click(648,230);await page.waitForFunction(()=>window.railvitoSnapshot.language==='ar');await shot('07-arabic-settings');
  await click(872,230);await page.waitForFunction(()=>window.railvitoSnapshot.language==='pt_BR');await shot('08-portuguese-settings');
  await click(424,230);await click(633,564);
  results.push('English, Arabic and Brazilian Portuguese settings');
  assert.equal(errors.length,0,'Runtime errors: '+errors.join('\n'));
  await context.close();
  fs.writeFileSync('build/playthrough-results.json',JSON.stringify({passed:true,checks:results,console_errors:errors},null,2));
  console.log('BROWSER_PLAYTHROUGH_PASS',results.length);
 } catch(e){
  fs.writeFileSync('build/playthrough-results.json',JSON.stringify({passed:false,checks:results,error:e.message,console_errors:errors},null,2));throw e;
 } finally {clearInterval(monitor);await browser.close();srv.kill()}
})().catch(e=>{console.error(e.stack);process.exit(1)});
