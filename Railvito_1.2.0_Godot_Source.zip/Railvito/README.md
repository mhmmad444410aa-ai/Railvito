# Railvito: Kids Train Games 3D

A native Godot 4.7.2 railway game for Android. Package: `com.mhmmad.railvito`.
Version: `1.2.0` / `3` (source update, build pending). Landscape, Android 7.0+ (API 24), target API 36.

## 1.2.0 source update — cab and scenery

Original low-poly 3D brake, speed lever and bell (with 2D fallback icons),
retro-style buttons, and a non-colliding low-poly horizon in six worlds.
Tap the bell to ring it in every mission. Tap the lever to switch speeds or
use the existing slider. Brake still uses the original stopping rules.
The third-party reference models are not bundled; these are original approximations.
No new gameplay routes, ads, permissions or signing key changes.
See `docs/UPDATE_1.2.0.md` for the exact scope and pending build checks.

## Inherited 1.1.0 delivery

Six worlds and eighteen short missions. Four outdoor worlds add eight authored
railways alongside the ten original missions. River Valley crosses a river by
bridge; Snowy Summit climbs an inclined railway past portals; Sky Gardens joins
separate floating landforms; Railway Town routes the train through a three-way
junction and guarded road crossing. Every new mission travels along an open
route. Junctions are selected at departure and lock after the train leaves the
platform. Bridge missions require placing and rotating missing decks.

English (UK) starts by default. Arabic shaping/RTL text and Brazilian Portuguese
are available from Settings. Sound effects only; no music, people or animals.
No advertising SDKs, accounts, analytics, Firebase, chat, or network permission.
Settings, selected engine and earned stars save locally.

This is a preview to evaluate the visual style and controls. It is **not the
160-level commercial release**. See `docs/STATUS.md` and `docs/TEST_REPORT.md` for
the exact verified scope and remaining work.

## Play

1. Select **Let's play**, or select a world and adventure.
2. In building missions, choose Straight or Bend. Rotate in 90° steps to match
   the glowing track, then drag to the gap. Selecting a piece and tapping a gap
   is also supported. Correct straight orientations are equivalent at 180°.
3. Undo and Redo work while the train is stopped. Hints select the matching piece
   and orientation; the player still places it. No timer or failure punishment.
4. Select Go and adjust the speed. A complete loop finishes building missions.
5. In driving missions, brake inside the numbered, coloured station ring.
6. In delivery missions, load the requested number of pumpkins before departing,
   then stop inside the destination ring.
7. Drag empty ground to orbit. Pinch/scroll to zoom, or use + and −. The circle
   button switches between a train-follow view and the overview.

Keyboard on desktop: `R` rotate, `Space` go/brake, `Ctrl+Z` undo, `Ctrl+Y` redo.

## Open source project

Import `project.godot` into the standard Godot 4.7.2 editor and run the main scene.
The source includes the original selected GLB files, their external palette
textures, original license files, and a SHA-256 asset manifest. No runtime asset
downloads are necessary. A fresh first editor import is required.

```sh
godot --headless --editor --import
godot --headless -- --self-test
python3 tools/verify_assets.py
XDG_DATA_HOME=/tmp/railvito-world-tests godot --headless --script res://tests/verify_worlds.gd
```

## GitHub Actions

The workflow is included at `.github/workflows/android.yml`. It imports the
models, runs checks, builds a debug APK, and builds/verifies a release APK when
the signing secrets exist. The workflow was prepared locally; this delivery
does not claim that a remote repository or successful Actions run exists.

Create these repository Actions secrets from the **separate private signing
backup**, never from files committed to the public repository:

| Secret | Value |
| --- | --- |
| `ANDROID_KEYSTORE_BASE64` | Base64 bytes of `railvito-release.keystore` |
| `ANDROID_KEY_ALIAS` | Key alias from the private backup |
| `ANDROID_KEYSTORE_PASSWORD` | Keystore password from the private backup |

The key and keystore share one password, as required by this Godot exporter.
Do not generate a different key for future updates. Keep the private backup.
The workflow uploads build artifacts; it does not automatically submit to stores.

## Architecture

| File | Responsibility |
| --- | --- |
| `scripts/rail_network.gd` | Shared rail geometry, arc-length curve, mission data |
| `scripts/world_builder.gd` | Original diorama composition, actual model instances, water |
| `scripts/main.gd` | Train following, interaction, mission state, UI, local saves |
| `scripts/strings.gd` | The three language dictionaries |
| `assets/manifest.json` | Per-file source, license and SHA-256 |
| `tools/verify_assets.py` | Verify assets and external GLB texture dependencies |

Coupled carriages sample the same curve at fixed distances, and body direction
comes from the front and rear axle positions. This supports both the original
closed circuits and the graded open routes. New track and bridge geometry uses
the same curve as the train. A railway with missing pieces blocks departure.
The city has one train and three destinations.

## Web validation build

The Web preset exports the **same Godot game**, without a separate Three.js
implementation. Serve the export directory over HTTPS or localhost. Godot 4
requires WebGL 2.0 and WebAssembly; a file opened directly from Downloads may not
work. Browser screenshots in this delivery are captures of this export.

## Ownership and third-party notices

Original game source and authored world composition are delivered to Mohammad
Suleiman for his project. A public source repository does not itself grant a
third-party license to the original game code. Included assets retain their
own licenses; see `THIRD_PARTY_LICENSES.md` and `licenses/`.

