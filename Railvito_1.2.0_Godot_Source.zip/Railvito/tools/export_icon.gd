extends SceneTree

func _init() -> void:
	var img := Image.load_from_file("res://assets/icon.svg")
	assert(img.get_width()==512 and img.get_height()==512)
	var err:=img.save_png("res://assets/icon_512.png")
	var license:=FileAccess.open("res://licenses/Godot-Engine-MIT.txt",FileAccess.WRITE)
	license.store_string(Engine.get_license_text())
	var third_party:=FileAccess.open("res://licenses/Godot-third-party-notices.json",FileAccess.WRITE)
	third_party.store_string(JSON.stringify({"copyright":Engine.get_copyright_info(),"licenses":Engine.get_license_info()},"  "))
	quit(0 if err==OK else 1)
