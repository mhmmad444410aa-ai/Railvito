"""Verify original third-party bytes, manifest paths, and glTF texture dependencies."""
from pathlib import Path
import json, struct, hashlib

root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'assets/manifest.json').read_text())
for item in manifest:
    p=root/item['file']
    assert p.is_file(),f'Missing asset: {p}'
    assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],f'Asset bytes changed: {p}'
    assert item['license']=='CC0-1.0'
    if p.suffix=='.glb':
        b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];data=json.loads(b[20:20+n])
        for image in data.get('images',[]):
            uri=image.get('uri','')
            if uri and not uri.startswith('data:'):assert (p.parent/uri).is_file(),f'Missing glTF texture: {p.parent/uri}'
for name in ['train-kit','nature-kit','castle-kit','ui-pack','holiday-kit','city-kit-suburban']:
    assert (root/'licenses'/(name+'-CC0.txt')).is_file()
print(f'ASSET_CHECK_OK: {len(manifest)} original files; SHA-256 and glTF dependencies verified')
