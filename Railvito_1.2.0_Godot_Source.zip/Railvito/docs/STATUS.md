# Current source: 1.2.0 (build pending)

See `UPDATE_1.2.0.md` for current changes and unverified gates. The following is historical status for 1.1.0.

# Railvito 1.1.0

The release APK includes four new outdoor 3D worlds and eight original missions.
The ten existing missions raise the total to eighteen across six worlds.

| World | Routes |
| --- | --- |
| River Valley | Fit missing bridge spans on one bank-to-bank route. Deliver crops through an alternate valley route. |
| Snowy Summit | Drive up an inclined line past two portals. Repair a viaduct on a different slope. |
| Sky Gardens | Fit bridges between floating islands. Deliver crops to an alternate island garden. |
| Railway Town | Choose a junction branch for a red-station delivery. Follow a different approach track and brake at the green station. |

The source contains both standalone native Android and Chromium-compatible Godot
exports. City switching is available before departure. The train remains on one
route during the journey. All eighteen stars slots are saved locally, including
values copied from an earlier ten-slot save.

The artwork uses original game terrain, rail layouts and bridges, and selected
CC0 trees, buildings and train models. Four screenshots depict the running
game. Network access, advertising, accounts and music are absent in the APK.

Physical Android gameplay, battery use and thermal performance remain untested.
The full set of planned free-build, customisation and educational modes remains
outside this update. The run of the remote Actions workflow and a public privacy
URL have yet to be verified.
