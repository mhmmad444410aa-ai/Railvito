# Asset, name and policy review

Reviewed 26 November 2026. This records the choices for the first preview,
not a claim to have audited every item in every catalog.

## Asset comparison

| Source | Findings relevant to this preview | Decision |
| --- | --- | --- |
| Kenney Train, Nature, Castle and UI kits | Matching low-poly proportions; actual downloadable GLB meshes; CC0 files included in archives; commercial use and public redistribution permitted | Selected and downloaded originals; selected files are actually bundled and instantiated |
| Kenney Landscape Kit | Requested URL returned HTTP 404 during direct check | Not bundled; terrain composed with the downloaded Nature Kit and original board mesh |
| Kenney Toy Car Kit | Catalog source considered; road vehicles are not needed to validate the railway loop | Not bundled |
| Quaternius Modular Train Pack | Official pack page lists 15 models, FBX/OBJ/Blend, CC0; catalog also contains packs using QAL, so a catalog-wide CC0 assumption would be incorrect | Kept as an alternative; not downloaded or redistributed in this preview |
| KayKit | Official catalog includes suitable forest/city kits; would require another palette/proportion integration pass | Not bundled in the first consistent Kenney-based composition |
| Poly Pizza | An asset directory with many creators; asset-level license and source attribution must be checked individually | No models taken from its catalog in this slice |
| Poly Haven | Official license allows commercial use and redistribution of its CC0 assets; emphasis is often photographic PBR | Not used for this toy-style slice |
| ambientCG | Official site identifies its assets as CC0; primarily PBR surfaces | Not used; avoids unnecessary large textures |
| Godot Shaders | Community shader library; each shader's license needs checking | Water shader written specifically for this project instead |
| OpenGameArt / Freesound | Licenses vary; Freesound explicitly includes noncommercial licenses | No sounds or models bundled from these sources; original SFX created locally |

Sources:
- https://kenney.nl/support
- https://quaternius.com/packs/modulartrain.html
- https://quaternius.com/faq.html
- https://kaylousberg.itch.io/
- https://poly.pizza/
- https://polyhaven.com/license
- https://ambientcg.com/index.php
- https://godotshaders.com/
- https://freesound.org/help/faq/

## Name and ASO

Exact-name web searches for Railvito did not surface a clear conflicting game in
the retrieved results; a connected GitHub repository-name search also returned
no Railvito repository. This is an initial discovery check only. It is not a
trademark registry clearance, an AppGallery name reservation, or a guarantee
that no unindexed or regional rights exist. WIPO, relevant national registries,
and the actual store consoles still need checking before final publication.

No verified keyword volume, conversion or competition dataset was available.
No search-volume figures are invented. Proposed descriptive phrases are Kids
Train Games, Toy Train, Railway Builder, Offline Train Puzzle; Arabic: ألعاب
القطارات للأطفال، بناء السكك، قطار ألعاب؛ pt-BR: jogos de trem para crianças,
construir ferrovia, trem de brinquedo. Do not use toddler claims without first
testing and adjusting the current rotate/drag interaction for younger children.

## Store policies

The review used the official policy pages below. The preview is not submitted
for publication and no approval is guaranteed.

| Source | Implication for this game |
| --- | --- |
| Huawei AppGallery content rules 4.1–4.3 | Keep useful original systems and varied content; multiple menu entries alone do not establish sufficient content or distinguish the app |
| Huawei protection-of-minors rules | Preserve age-appropriate content and privacy; accurately declare the intended audience |
| Petal Ads privacy/children policy | Child requests require explicit child flags and appropriate content ratings; personalised child advertising is prohibited. This preview integrates no ads |
| Uptodown publication criteria | Working software, accurate purpose, rights to assets, original functionality and suitable images are required; template clones and intrusive advertising may be rejected |
| APKPure distribution agreement | Developer must hold distribution rights and supply accurate, lawful, non-deceptive content |

Official sources:
- https://developer.huawei.com/consumer/en/doc/app/50104-04/
- https://developer.huawei.com/consumer/en/doc/app/50104-08/
- https://developer.huawei.com/consumer/en/doc/app/50104-07
- https://developer.huawei.com/consumer/en/doc/monetize/policy4-0000001146675575
- https://support.uptodown.com/hc/en-us/articles/360052792972-Uptodown-s-app-publication-criteria
- https://apkpure.net/developer-distribution-agreement

The supplied privacy text reflects the actual ad-free, offline preview. It has
not yet been placed at a live HTTPS URL or tested from Huawei review devices.
