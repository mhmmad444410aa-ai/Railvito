# Preview descriptions — not a final store submission

These drafts describe only the implemented preview. No search-volume claims,
trademark clearance or store acceptance is implied.

## English (UK)

**Name:** Railvito: Kids Train Games 3D

**Short:** Build toy railways, drive little trains and count cargo in two 3D worlds.

**Long:** Explore a miniature toy railway in Railvito. Choose a little steam,
diesel or electric train and discover ten introductory adventures in Woodland
Workshop and Waterfall Gardens. Complete glowing gaps in the track, rotate and
snap pieces into place, then drive your train around the railway. Slow down and
brake at numbered stations, or count pumpkins and deliver the right amount of
cargo. Undo, redo and visual hints help children experiment at their own pace.
Rotate and zoom the camera, follow the train, and earn stars through play.
Progress and settings stay on the device. This preview works offline, contains
sound effects without music, and has no adverts, accounts or purchases. Choose
English, Arabic or Brazilian Portuguese in Settings. Intended audience: ages
4–10; younger children may benefit from a grown-up's help with rotation.

**Candidate keywords:** kids train games; toy train; railway builder; train
puzzle; offline train game; count and deliver; educational train.

## العربية

**الاسم:** ريلفيتو: ألعاب القطارات للأطفال

**الوصف القصير:** ابنِ سكك الألعاب وقُد القطارات وتعلّم العد في عالمين ثلاثيي الأبعاد.

**الوصف الطويل:** استكشف عالم قطارات مصغرًا في ريلفيتو. اختر القطار البخاري أو
الديزل أو الكهربائي، والعب عشر مغامرات تمهيدية في ورشة الغابة وحدائق الشلالات.
أكمل الفراغات المضيئة في السكة، ودوّر القطع وثبّتها ثم شغّل قطارك. خفّف السرعة
وتوقف عند المحطة المرقمة، أو عُدّ حبات اليقطين وأوصل الكمية الصحيحة. تساعدك
أزرار التراجع والإعادة والتلميحات على التجربة دون ضغط زمني. دوّر الكاميرا أو
قرّبها واتبع القطار واجمع النجوم من اللعب. يُحفظ التقدم والإعدادات على الجهاز.
تعمل هذه النسخة الأولية دون إنترنت، بمؤثرات صوتية دون موسيقى، ودون إعلانات أو
حسابات أو مشتريات. تتوفر العربية والإنجليزية والبرتغالية البرازيلية. تستهدف
الأعمار 4–10 سنوات؛ قد يحتاج الأصغر سنًا مساعدة أحد الوالدين في تدوير القطع.

**كلمات مقترحة:** ألعاب القطارات للأطفال؛ بناء السكك؛ قطار ألعاب؛ ألغاز القطار؛
لعبة قطار دون إنترنت؛ تعلم العد؛ قيادة القطار.

## Português do Brasil

**Nome:** Railvito: Jogos de Trem 3D

**Curta:** Construa trilhos, dirija trenzinhos e conte cargas em dois mundos 3D.

**Longa:** Descubra uma ferrovia de brinquedo em Railvito. Escolha um trem a
vapor, diesel ou elétrico e explore dez aventuras introdutórias na Oficina da
Floresta e nos Jardins da Cachoeira. Preencha lacunas brilhantes, gire e encaixe
peças, depois leve seu trem para uma volta. Diminua a velocidade e freie nas
estações numeradas, ou conte abóboras e entregue a quantidade certa. Desfazer,
refazer e dicas visuais ajudam a experimentar sem cronômetro. Gire e amplie a
câmera, acompanhe o trem e ganhe estrelas brincando. Progresso e configurações
ficam no aparelho. Esta prévia funciona offline, com efeitos sonoros sem música,
sem anúncios, contas ou compras. Escolha inglês, árabe ou português do Brasil.
Público pretendido: 4–10 anos; crianças menores podem precisar de ajuda de um
responsável para girar as peças.

**Palavras candidatas:** jogos de trem para crianças; trem de brinquedo;
construir ferrovia; quebra-cabeça de trem; trem offline; contar cargas.
