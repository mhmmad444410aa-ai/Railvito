# Railvito 1.2.0 — source update, 26 November 2026

Package: `com.mhmmad.railvito`, versionCode 3. Previous source version: 1.1.0.

## Changes
- All 18 missions use the same redesigned cab-style controls. The bell is available in every playable mission, with an original short sound and a swinging 3D model.
- The red brake model moves downward when pressed and calls the existing brake function; the speed lever cycles 1.4 / 2.8 / 4.8 and follows slider changes.
- Original 2D control symbols for rotate, undo, redo, zoom and go; all visible labels and existing locale logic remain in English (UK), Arabic and Brazilian Portuguese.
- Original 3D scenery ring with lower hills (snowy palette for Summit, clouds for Sky Gardens), outside the gameplay route, without collision shapes or cast shadows.
- Original approximations of the approved design references 4, 11, 13, 14, 16 and 17. The actual Charlie, Babycheeses11, Quaternius, Zoe XR and Lucide assets have NOT been downloaded or bundled. No third-party reference artwork has been copied into the source. The background treatment is a design choice based on the requested low hills, not a confirmed selection of a specific third-party pack.
- Original track/mission data and main scene preserved byte for byte; no new missions, account system, ad SDK, network permission or music.
- Existing Android CI workflow now includes a cab smoke test and rejects a release signed with a different certificate. Keep the existing private signing backup; do not commit it to a public repository.

## Verified in the current environment
- All 45 original third-party asset bytes match the original SHA-256 manifest. GLB texture dependencies are present.
- New 9 SVGs parse as XML. Original bell WAV has valid mono audio and nonzero samples.
- Literal asset references resolve and expected original gameplay source files are byte-identical to 1.1.0.
- Package, version, and offline Internet-permission flag checked in the Android export preset.
- The previous engine and browser test results are historical only; see docs/TEST_REPORT.md (1.1.0).

## Not verified / release gates
- Godot 4.7.2 and Android export templates are not installed in the current container. The download attempt failed at DNS resolution. No engine compile, rendering, interaction test, device test, or new APK build was performed. New scripts may still require correction after Godot import.
- `tests/verify_cab.gd` is provided for execution in Godot and CI; it has not been executed here. The full visual HUD and 3D rendering must be verified on a physical Android device, in all locales and on multiple aspect ratios.
- No Railvito repository was found in the connected GitHub account. No GitHub push, Actions run, or store submission took place.
- This is not yet a release APK or a store-ready build.

## Next verification
Open this project in Godot 4.7.2, import assets, then run:

```sh
godot --headless --editor --import
godot --headless -- --self-test
godot --headless --script res://tests/verify_engines.gd
XDG_DATA_HOME=/tmp/railvito-world-tests godot --headless --script res://tests/verify_worlds.gd
XDG_DATA_HOME=/tmp/railvito-cab-tests godot --headless --script res://tests/verify_cab.gd
python3 tools/verify_assets.py
```

Render and play every mission; inspect the HUD, background, performance and touch targets. Export release with the original signing key only after checks pass. Verify package, versionCode 3 and existing certificate before replacing any installed APK.
