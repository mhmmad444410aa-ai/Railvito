# Railvito 1.1.0 verification

- Godot completed the original ten mission checks.
- Eight added missions were completed using the same motion, rail placement,
  braking, undo/redo and switching code used in the game. An incomplete bridge
  blocked starting. Delivering to the wrong station did not award stars.
- An isolated native Godot test read a ten-slot save and preserved its existing
  stars in the new eighteen-slot save structure.
- Chromium rendered all four new worlds. The browser playthrough completed a
  real drag-and-drop bridge puzzle and a real city cargo delivery through the UI.
- Chromium also restored the two new star awards after reload.
- The new release was built from the existing project and signed with the
  original certificate. Android SDK verification confirms APK signature
  schemes v2 and v3, package com.mhmmad.railvito, version 1.1.0 (2),
  ARM64 and ARMv7, min SDK 24, target SDK 36 and no Android permissions.
- The final APK has yet to be tested on an Android phone.

See CERTIFICATE_SHA256.txt for the verified certificate and APK hashes.
