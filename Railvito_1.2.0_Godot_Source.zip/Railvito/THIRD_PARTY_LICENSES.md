# Third-party assets and notices

Reviewed and downloaded on 26 November 2026. The exact original license files
are preserved in `licenses/`. `assets/manifest.json` identifies every included
third-party asset, source URL, license and SHA-256. No preview image from an
asset store is used as a model or as a gameplay background.

| Included source | Author | License | Commercial use and public source redistribution |
| --- | --- | --- | --- |
| [Train Kit 1.1](https://kenney.nl/assets/train-kit) | Kenney; additional credits Guus Vermeulen, Tony Schaer | CC0 1.0 | Allowed under CC0 |
| [Nature Kit 2.1](https://kenney.nl/assets/nature-kit) | Kenney | CC0 1.0 | Allowed under CC0 |
| [Castle Kit](https://kenney.nl/assets/castle-kit) | Kenney | CC0 1.0 | Allowed under CC0 |
| [UI Pack](https://kenney.nl/assets/ui-pack) | Kenney | CC0 1.0 | Allowed under CC0 |
| [Holiday Kit](https://kenney.nl/assets/holiday-kit), snowy trees only | Kenney | CC0 1.0 | Allowed under CC0 |
| [City Kit (Suburban)](https://kenney.nl/assets/city-kit-suburban), selected building meshes and original palette | Kenney | CC0 1.0 | Allowed under CC0 |
| DejaVu Sans | DejaVu and Bitstream contributors | Bitstream Vera / DejaVu terms | Distribution allowed with included notices |
| Noto Naskh Arabic Bold | Noto contributors | SIL Open Font License 1.1 | Distribution allowed with included notices |
| Godot Engine | Godot contributors | MIT and third-party notices | MIT text is accessible from About; full engine notice export is included in `licenses/` |

Kenney's support page confirms the CC0 commercial-use terms:
https://kenney.nl/support . CC0 text: https://creativecommons.org/publicdomain/zero/1.0/ .

The models and palette textures are copied without altering the original file
bytes. Runtime placement, scaling, material roughness, roof colour overrides and
wheel animation do not change those source bytes. The water shader, toy board,
sound effects, game logic and diorama composition are original work for this
project. No third-party music, sound recordings, shaders or model preview renders
are bundled. Kenney's logo is not used.

## Original archive verification

| Archive | SHA-256 |
| --- | --- |
| Train Kit | `cf50d77e8cbacbf38dd50826d4bce5392db8e4f67373d3c4e583b0ed0e474475` |
| Nature Kit | `fa7974a0d342bfe63c38664ba9f8ec1a4aab8ea25f099bdc56870e33588c4d9d` |
| Castle Kit | `921f3f73927bb23106cae34bc21d5ab4b033a9fc120475e96f714a406e3169df` |
| UI Pack | `a8a14a234911eb648c062622915c93e79e94e97cb7f9f375a70f6617f1174318` |

| Holiday Kit | `fde4d514d7297388d98058e8933ff614e071886f7ce57f9aea4b00d7698dd769` |
| City Kit (Suburban) | `5869c35cf30b1c87bdb2d197b6d325eebadd2ef08ea27f04797e8e08d77a9a39` |

New terrain, rail meshes, bridge geometry, island landforms, barriers and shaders
were authored for Railvito. Snow trees and suburban buildings are imported
from the original archives. No Poly Pizza island was copied into this build.

Only the selected assets used by this preview are included, not the complete
archives. Full font notices are preserved alongside the original asset licenses.

