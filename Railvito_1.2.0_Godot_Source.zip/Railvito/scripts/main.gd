extends Node3D

const Network = preload("res://scripts/rail_network.gd")
const Builder = preload("res://scripts/world_builder.gd")
const Words = preload("res://scripts/strings.gd")
const Cab = preload("res://scripts/cab_controls.gd")
const CREAM := Color("fff8e8")
const INK := Color("304b50")
const TEAL := Color("317f79")
const CORAL := Color("db7357")
const GOLD := Color("eab45a")
const SAVE_PATH := "user://railvito.cfg"

var world: Node3D
var art
var rails: Node3D
var train_root: Node3D
var camera: Camera3D
var route: Dictionary
var track_nodes: Array[Node3D] = []
var ghost_nodes := {}
var missing: Array = []
var undo_stack: Array = []
var redo_stack: Array = []
var cars: Array[Node3D] = []
var wheels: Array[Node3D] = []
var steam: Array = []
var steam_pool: Array[MeshInstance3D] = []
var confetti: Array = []
var goal_ring: MeshInstance3D
var parcel_nodes: Array[Node3D] = []
var ui: Control
var modal: Control
var task_label: Label
var status_label: Label
var speed_slider: HSlider
var bell_model: Node3D
var brake_model: Node3D
var lever_model: Node3D
var bell_count := 0
var bell_tween: Tween
var brake_tween: Tween
var toast_label: Label
var selected_label: Label
var selected_buttons: Dictionary = {}
var drag_label: Label
var drag_model: Node3D
var language := "en_GB"
var screen := "menu"
var level_index := 0
var world_id := 0
var train_choice := 0
var selected_kind := "straight"
var selected_yaw := 0
var dragging_piece := false
var orbiting := false
var camera_follow := false
var pointer := Vector2.ZERO
var touches := {}
var pinch_previous := 0.0
var distance := 1.2
var travelled := 0.0
var speed := 0.0
var desired_speed := 0.0
var speed_setting := 2.8
var cargo_count := 0
var loaded_count := 0
var goal_distance := 0.0
var won := false
var low_graphics := false
var evening := false
var sound_volume := 0.65
var stars: Array = []
var switch_index := 1
var switch_label: Label
var city_routes: Array[Dictionary] = []
var brake_requested := false
var hint_used := false
var timer := 0.0
var steam_clock := 0.0
var sound_clock := 0.0
var yaw := 0.48
var pitch := 0.64
var zoom := 28.5
var target := Vector3.ZERO
var tone: AudioStreamPlayer
var train_sound: AudioStreamPlayer
var last_save_error := OK
var web_clock := 0.0

func t(key: String) -> String:
	return Words.get_text(key,language)

func _ready() -> void:
	stars.resize(Network.levels().size())
	stars.fill(0)
	_load_save()
	Engine.max_fps = 60
	tone=AudioStreamPlayer.new();add_child(tone)
	train_sound=AudioStreamPlayer.new();add_child(train_sound)
	_set_audio_volume()
	_create_world(0)
	_show_menu()
	if OS.has_feature("web"):
		# The browser uses the same scenes and GDScript as the Android build.
		JavaScriptBridge.eval("window.railvitoReady = true;")
	if "--self-test" in OS.get_cmdline_user_args():
		call_deferred("_self_test")

func _create_world(id: int, data: Dictionary = {}) -> void:
	if is_instance_valid(world):
		remove_child(world);world.queue_free()
	world_id=id
	world=Node3D.new();world.name="ToyWorld";add_child(world)
	var mission: Dictionary=Network.world_levels(id)[0] if data.is_empty() else data
	route=Network.for_level(mission)
	distance=float(route.get("spawn",1.2))
	switch_index=1
	city_routes.clear()
	art=Builder.new()
	art.build(world,id,route)
	rails=Node3D.new();world.add_child(rails)
	track_nodes.clear();ghost_nodes.clear();steam.clear();steam_pool.clear();confetti.clear();parcel_nodes.clear()
	drag_model=null
	for piece in route.pieces:
		track_nodes.append(_track_visual(piece,route))
	if id==5:
		for branch in range(3):
			var line: Dictionary=Network.for_level(mission,branch)
			city_routes.append(line)
			if branch!=1:
				var first_branch_segment:=2 if mission.variant==0 else 3
				for piece in line.pieces:
					if piece.segment>=first_branch_segment:
						_track_visual(piece,line)
	_create_train()
	goal_ring=null
	camera=Camera3D.new();world.add_child(camera)
	camera.projection=Camera3D.PROJECTION_ORTHOGONAL
	camera.size=zoom;camera.near=0.1;camera.far=150
	camera.current=true
	art.sun.shadow_enabled=not low_graphics
	_set_evening(evening)
	target=Vector3.ZERO
	_update_camera(1.0)

func _track_visual(piece: Dictionary, line: Dictionary, ghost: Material = null) -> Node3D:
	if line.get("open",false):
		return art.outdoors.track(piece,line,ghost)
	var asset := "railroad-straight" if piece.kind=="straight" else "railroad-corner-small"
	var obj: Node3D=art.model("train-kit",asset,piece.pos+Vector3(0,1,0),Vector3.ONE,piece.yaw)
	if ghost:
		_override(obj,ghost)
	return obj

func _create_train() -> void:
	if is_instance_valid(train_root):
		train_root.queue_free()
	train_root=Node3D.new();world.add_child(train_root)
	cars.clear();wheels.clear();parcel_nodes.clear()
	for p in steam_pool:
		if is_instance_valid(p):p.queue_free()
	steam_pool.clear();steam.clear()
	var engines := ["train-locomotive-a","train-diesel-a","train-electric-city-a"]
	for i in range(3):
		var obj: Node3D = art.model("train-kit",engines[train_choice] if i==0 else "train-carriage-flatbed" if i==2 else "train-carriage-box")
		obj.reparent(train_root)
		cars.append(obj)
		_collect_wheels(obj)
	for i in range(4):
		var p: Node3D = art.model("nature-kit","crop_pumpkin")
		p.reparent(cars[2]);p.position=Vector3(-0.24+(i%2)*0.48,0.43,(i/2)*0.5-0.3);p.scale=Vector3.ONE*0.75
		p.visible=false;parcel_nodes.append(p)
	var puff_mesh:=SphereMesh.new();puff_mesh.radius=0.14;puff_mesh.height=0.28;puff_mesh.radial_segments=8;puff_mesh.rings=4
	var puff_material: Material=art.material("f6f2de")
	for i in range(12):
		var p: MeshInstance3D=art.mesh_node(puff_mesh,puff_material,Vector3.ZERO)
		p.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;p.visible=false;steam_pool.append(p)
	_update_train(0)

func _collect_wheels(node: Node) -> void:
	if node is Node3D and (node.name.to_lower().begins_with("wheel")):
		wheels.append(node)
		# Children of a complete bogie are rotated by the parent only.
		return
	for child in node.get_children(): _collect_wheels(child)

func _set_ui() -> void:
	if is_instance_valid(ui):
		remove_child(ui);ui.queue_free()
	modal=null
	bell_model=null;brake_model=null;lever_model=null
	ui=Control.new();ui.name="Interface"
	ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var theme := Theme.new()
	var font: Font=load("res://assets/fonts/NotoNaskhArabic-Bold.ttf" if language=="ar" else "res://assets/fonts/DejaVuSans.ttf")
	if language=="ar":
		font=font.duplicate();font.fallbacks=[load("res://assets/fonts/DejaVuSans.ttf")]
	theme.default_font=font
	theme.default_font_size=18
	ui.theme=theme
	# Mirror positions explicitly. Inherited RTL anchors would also move controls
	# relative to their original, unmirrored panels and overlap the header.
	ui.layout_direction=Control.LAYOUT_DIRECTION_LTR
	toast_label=null;drag_label=null

func _flow_position(pos: Vector2, extent: Vector2, parent: Control=null) -> Vector2:
	var host: Control=parent if parent else ui
	return Vector2(host.size.x-pos.x-extent.x,pos.y) if language=="ar" else pos

func _box(color: Color, radius := 22, depth := 0) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.set_corner_radius_all(radius)
	style.content_margin_left=18;style.content_margin_right=18
	style.content_margin_top=10;style.content_margin_bottom=10
	style.border_width_bottom=depth;style.border_color=color.darkened(0.15)
	style.shadow_color=Color(0.16,0.25,0.23,0.12);style.shadow_size=8;style.shadow_offset=Vector2(0,4)
	return style

func _cab_style(color: Color, pressed := false) -> StyleBoxFlat:
	var style := _box(color.darkened(0.08) if pressed else color,12,2 if pressed else 5)
	style.set_border_width_all(2)
	style.border_width_bottom=2 if pressed else 5
	style.border_color=Color("263b47")
	style.content_margin_left=8;style.content_margin_right=8
	style.content_margin_top=4;style.content_margin_bottom=4
	return style

func _cab_icon(button: Button, name: String, width := 26) -> void:
	button.icon=load("res://assets/cab/"+name+".svg")
	button.add_theme_constant_override("icon_max_width",width)
	button.expand_icon=true
	if not button.text.is_empty():button.add_theme_font_size_override("font_size",17)

func _panel(pos: Vector2, size: Vector2, color := CREAM, parent: Control = null) -> Panel:
	var p := Panel.new();(parent if parent else ui).add_child(p)
	p.position=pos;p.size=size;p.add_theme_stylebox_override("panel",_box(color))
	p.position=_flow_position(pos,size,parent)
	p.mouse_filter=Control.MOUSE_FILTER_STOP
	return p

func _label(text: String, pos: Vector2, size: Vector2, font_size := 22, color := INK, parent: Control = null) -> Label:
	var l := Label.new();(parent if parent else ui).add_child(l)
	l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	l.position=pos;l.size=size;l.text=text
	l.add_theme_font_size_override("font_size",font_size)
	l.add_theme_color_override("font_color",color)
	l.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter=Control.MOUSE_FILTER_IGNORE
	if language=="ar":
		l.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
		l.text_direction=Control.TEXT_DIRECTION_RTL
	l.position=_flow_position(pos,size,parent)
	return l

func _button(text: String, pos: Vector2, size: Vector2, callback: Callable, color := CREAM, parent: Control = null) -> Button:
	var b := Button.new();(parent if parent else ui).add_child(b)
	b.position=pos;b.size=size;b.text=text
	b.add_theme_stylebox_override("normal",_cab_style(color))
	b.add_theme_stylebox_override("hover",_cab_style(color.lightened(0.055)))
	b.add_theme_stylebox_override("pressed",_cab_style(color,true))
	b.add_theme_stylebox_override("focus",_box(Color(color,0),18,0))
	b.add_theme_color_override("font_color",INK if color.get_luminance()>0.48 else CREAM)
	b.add_theme_color_override("font_hover_color",INK if color.get_luminance()>0.48 else CREAM)
	b.add_theme_color_override("font_pressed_color",INK if color.get_luminance()>0.48 else CREAM)
	b.add_theme_font_size_override("font_size",20)
	b.focus_mode=Control.FOCUS_NONE
	if language=="ar":b.text_direction=Control.TEXT_DIRECTION_RTL
	b.position=_flow_position(pos,b.size,parent)
	b.pressed.connect(func(): _play_sound("click");callback.call())
	return b

func _right(node: Control, x: float, y: float) -> void:
	var extent:=node.size
	node.set_meta("right_attached",true)
	node.anchor_left=0 if language=="ar" else 1;node.anchor_right=node.anchor_left
	var left:=-x-extent.x if language=="ar" else x
	node.offset_left=left;node.offset_right=left+extent.x
	node.offset_top=y;node.offset_bottom=y+extent.y

func _bottom(node: Control, x: float, y: float) -> void:
	var extent:=node.size
	node.anchor_top=1;node.anchor_bottom=1
	var left:=x
	if language=="ar":
		if node.has_meta("right_attached"):
			left=-x-extent.x;node.anchor_left=0;node.anchor_right=0
		else:
			left=-x-extent.x;node.anchor_left=1;node.anchor_right=1
	node.offset_left=left;node.offset_right=left+extent.x
	node.offset_top=y;node.offset_bottom=y+extent.y

func _show_menu() -> void:
	if world_id!=0:
		_create_world(0)
	screen="menu";missing.clear();won=false;desired_speed=2.3;speed=2.3;distance=3;camera_follow=false
	for n in track_nodes:n.visible=true
	yaw=0.48;pitch=0.64;zoom=30.8;target=Vector3(3.2 if language=="ar" else -3.2,0,0)
	_set_ui()
	_label("RAILVITO",Vector2(42,25),Vector2(340,65),44,TEAL)
	_label("KIDS TRAIN GAMES 3D",Vector2(45,83),Vector2(340,30),15,INK)
	var badge := _panel(Vector2.ZERO,Vector2(220,42),Color("eaf0d5"));_right(badge,-258,38)
	var tick:=TextureRect.new();badge.add_child(tick);tick.texture=load("res://assets/ui/icon_checkmark.png");tick.position=Vector2(11,12);tick.size=Vector2(20,20);tick.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	tick.position=_flow_position(Vector2(11,12),Vector2(20,20),badge)
	var btext := _label(t("preview"),Vector2(36,0),Vector2(174,42),13,TEAL,badge);btext.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var p := _panel(Vector2(40,202),Vector2(365,370),Color(1,0.975,0.91,0.95))
	_label(t("tagline"),Vector2(25,14),Vector2(325,123),37,TEAL,p)
	_label(t("intro"),Vector2(25,137),Vector2(320,68),18,INK,p)
	_button(t("play") if stars.count(0)==stars.size() else t("resume"),Vector2(24,224),Vector2(316,64),_continue,CORAL,p)
	_button(t("worlds"),Vector2(24,302),Vector2(316,49),_show_worlds,Color("f6dfab"),p)
	var row := _panel(Vector2.ZERO,Vector2(760,72),Color(1,0.98,0.92,0.93));_bottom(row,40,-105)
	_button(t("train"),Vector2(10,9),Vector2(245,52),_train_menu,CREAM,row)
	_button(t("settings"),Vector2(265,9),Vector2(210,52),_settings,CREAM,row)
	_button(t("parents"),Vector2(487,9),Vector2(260,52),_parents_gate,CREAM,row)
	_label(t("no_timer"),Vector2(820,640),Vector2(420,40),16,INK)

func _continue() -> void:
	var next:=stars.find(0,10)
	if next<0:
		next=stars.find(0)
	_start_level(10 if next<0 else next)

func _show_worlds() -> void:
	screen="worlds";_set_ui()
	_button(t("back"),Vector2(32,30),Vector2(155,54),_show_menu)
	var head := _label(t("choose_world"),Vector2(210,25),Vector2(870,60),32,TEAL)
	head.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var palettes := ["e8f1cc","e8f0fa","f0e7fa","fee7cc","fff6de","d9ece3"]
	var display_order := [2,3,4,5,0,1]
	for i in range(display_order.size()):
		var id: int=display_order[i]
		var pos := Vector2(50+(i%3)*400,125+floori(float(i)/3.0)*245)
		var card := _panel(pos,Vector2(380,215),Color(palettes[i]))
		_label(t(Network.WORLD_NAMES[id]),Vector2(22,12),Vector2(336,64),23,TEAL,card)
		_label(t("mission_count") % Network.world_levels(id).size(),Vector2(22,81),Vector2(320,50),18,INK,card)
		_button(t("play"),Vector2(20,139),Vector2(340,55),func(): _show_levels(id),TEAL,card)

func _show_levels(id: int) -> void:
	if world_id!=id or id>=2:
		_create_world(id)
	missing.clear()
	screen="levels";desired_speed=1.8;speed=1.8;camera_follow=false
	zoom=38 if id>=2 else 31;target=Vector3.ZERO
	for n in track_nodes:n.visible=true
	for n in ghost_nodes.values():n.visible=false
	_set_ui();_button(t("back"),Vector2(32,28),Vector2(155,54),_show_worlds)
	_label(t(Network.WORLD_NAMES[id]),Vector2(225,25),Vector2(870,65),34,TEAL)
	var p := _panel(Vector2(80,460),Vector2(1120,202),Color(1,0.98,0.91,0.97))
	_label(t("choose_level"),Vector2(24,6),Vector2(1050,40),22,TEAL,p)
	var entries: Array=Network.world_levels(id)
	var width:=1068.0/entries.size()
	for i in range(entries.size()):
		var mission: Dictionary=entries[i]
		var idx: int=mission.id
		var mark:=("   "+"★".repeat(stars[idx])) if stars[idx]>0 else ""
		_button(t(mission.title)+mark,Vector2(22+i*width,58),Vector2(width-10,64),func(): _start_level(idx),GOLD if stars[idx]>0 else Color("e0edd8"),p)
		_label(t(mission.mode),Vector2(22+i*width,126),Vector2(width-10,52),16,INK,p).horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER

func _start_level(index: int) -> void:
	level_index=clampi(index,0,Network.levels().size()-1)
	var data: Dictionary=Network.levels()[level_index]
	_create_world(data.world,data)
	screen="game";won=false;hint_used=false;camera_follow=false
	travelled=0;speed=0;desired_speed=0;speed_setting=2.8;brake_requested=false
	selected_kind="bridge" if world_id>=2 and data.mode=="build" else "straight";selected_yaw=0;dragging_piece=false
	cargo_count=0;loaded_count=0;undo_stack.clear();redo_stack.clear()
	if data.has("missing"):
		missing=data.missing.duplicate()
	elif data.mode=="build":
		missing=Network.Adventures.gaps(route,true)
	else:
		missing=[]
	for idx in missing:
		track_nodes[idx].visible=false
		var piece: Dictionary=route.pieces[idx]
		var mat:=StandardMaterial3D.new()
		mat.albedo_color=Color(1,0.78,0.24,0.56)
		mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
		var ghost:=_track_visual(piece,route,mat)
		ghost_nodes[idx]=ghost
		var ring := TorusMesh.new()
		ring.inner_radius=0.62;ring.outer_radius=0.78;ring.rings=24;ring.ring_segments=8
		var n: MeshInstance3D=art.mesh_node(ring,art.material("f1bb53"),piece.center+Vector3(0,0.025,0))
		n.name="GapMarker"
		n.reparent(ghost)
		_add_track_marker(ghost,piece.center)
	if data.mode!="build" or route.get("open",false):
		_create_goal(data.station)
	yaw=0.29 if world_id>=2 else 0.40
	pitch=0.62 if world_id==4 else (0.78 if world_id>=2 else 0.72)
	zoom=39.0 if world_id>=2 else (29.5 if world_id==0 else 31.5)
	target=Vector3.ZERO
	_update_train(0);_update_camera(1);_game_ui()

func _add_track_marker(ghost: Node3D, center: Vector3) -> void:
	if not route.get("open",false):
		return
	var mark:=Label3D.new()
	mark.text=t("bridge")
	mark.font_size=42
	mark.pixel_size=0.011
	mark.modulate=Color("fff4d8")
	mark.outline_modulate=Color("83522e")
	mark.outline_size=10
	mark.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	ghost.add_child(mark)
	mark.global_position=center+Vector3.UP*0.94

func _override(n: Node, mat: Material) -> void:
	if n is MeshInstance3D:n.material_override=mat
	for c in n.get_children():_override(c,mat)

func _create_goal(station: int) -> void:
	var station_offset:=1 if world_id in [2,3,4] else 0
	var s: Dictionary=art.stations[station+station_offset]
	var horizontal := 8.0 if world_id==0 else 6.0
	var vertical := 6.0 if world_id==0 else 8.0
	var pos := Vector3(s.pos.x,0.16,vertical if station==0 else -vertical if station==1 else s.pos.z)
	if station==2:pos.x=-horizontal
	var point: Vector3
	if route.get("open",false):
		goal_distance=float(route.end_stop) if world_id!=5 or switch_index==station else -1.0
		if world_id==5:
			var target_line: Dictionary=city_routes[station]
			point=target_line.curve.sample_baked(target_line.end_stop)
		else:
			point=route.curve.sample_baked(route.end_stop)
	else:
		goal_distance=route.curve.get_closest_offset(pos)
		point=route.curve.sample_baked(goal_distance)
	if is_instance_valid(goal_ring):
		goal_ring.queue_free()
	var ring:=TorusMesh.new();ring.inner_radius=1.1;ring.outer_radius=1.30;ring.rings=40;ring.ring_segments=8
	goal_ring=art.mesh_node(ring,art.material(s.color.to_html()),point+Vector3(0,0.075,0))
	goal_ring.scale=Vector3(1.2,0.3,1.2)

func _game_ui() -> void:
	_set_ui();selected_buttons.clear()
	var data: Dictionary=Network.levels()[level_index]
	var header:=_panel(Vector2(24,20),Vector2(800,74),Color(1,0.98,0.92,0.96))
	_button("⌂",Vector2(9,9),Vector2(62,54),func(): _show_levels(world_id),Color("e4ecd6"),header)
	_label(t(data.title),Vector2(85,5),Vector2(590,37),24,TEAL,header)
	_label(t("level") % (level_index+1)+"  ·  "+t(data.mode),Vector2(86,40),Vector2(605,25),14,INK,header)
	var bell_button:=_button(t("bell"),Vector2.ZERO,Vector2(124,54),_ring_bell,Color("f1cd82"));_right(bell_button,-278,30)
	bell_button.name="CabBell"
	bell_model=Cab.attach(bell_button,"bell",load("res://assets/cab/bell.svg"),32)
	var btn:=_button("?",Vector2.ZERO,Vector2(56,54),_help);_right(btn,-146,30)
	btn=_button("☷",Vector2.ZERO,Vector2(56,54),_settings);_right(btn,-82,30)
	var task:=_panel(Vector2(26,112),Vector2(340,146),Color(1,0.98,0.90,0.96))
	var instruction:=t("build_task") if data.mode=="build" else t("drive_task") % (data.station+1) if data.mode=="drive" else t("cargo_task") % [data.number,data.station+1]
	if world_id>=2 and data.mode=="build":
		instruction=t("bridge_task")
	elif world_id==5:
		instruction=t("city_cargo_task") % [data.number,data.station+1] if data.mode=="cargo" else t("city_route_task") % (data.station+1)
	task_label=_label(instruction,Vector2(16,9),Vector2(307,100),18,INK,task);task_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	status_label=_label("",Vector2(16,108),Vector2(307,28),16,TEAL,task)
	var controls:=_panel(Vector2.ZERO,Vector2(830,112),Color(1,0.98,0.92,0.98));_bottom(controls,24,-136)
	if data.mode=="build":
		for i in range(2):
			var kind: String=["straight","curve"][i]
			if world_id>=2:
				kind=["bridge","straight"][i]
			var b:=_button(("═  " if kind=="bridge" else ("║  " if kind=="straight" else "╰  "))+t(kind),Vector2(12+i*143,13),Vector2(135,62),func(): _select_piece(kind),Color("e7d8af") if i==0 else Color("e8eedb"),controls)
			b.button_down.connect(func(): _begin_drag(kind))
			selected_buttons[kind]=b
		_cab_icon(_button(t("rotate").replace("↻","").strip_edges(),Vector2(302,13),Vector2(120,62),_rotate_piece,Color("f3d391"),controls),"rotate",20)
		_cab_icon(_button(t("undo").replace("↶","").strip_edges(),Vector2(430,13),Vector2(120,62),_undo,CREAM,controls),"undo",20)
		_cab_icon(_button(t("redo").replace("↷","").strip_edges(),Vector2(558,13),Vector2(120,62),_redo,CREAM,controls),"redo",20)
		_button(t("hint"),Vector2(686,13),Vector2(132,62),_hint,CREAM,controls)
		selected_label=_label("",Vector2(16,79),Vector2(790,25),14,INK,controls)
	else:
		_label(t("load") if data.mode=="cargo" else t("speed"),Vector2(16,8),Vector2(175,31),20,TEAL,controls)
		if data.mode=="cargo":
			for i in range(1,5):
				_button(str(i),Vector2(190+(i-1)*80,14),Vector2(68,62),func(): _load_cargo(i),Color("f0d49b"),controls)
		elif world_id!=5:
			_label(t("station_hint"),Vector2(180,14),Vector2(600,64),18,INK,controls).autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		if world_id==5:
			_switch_controls(controls,data.mode=="cargo")
		_label(t("saved"),Vector2(16,78),Vector2(790,26),14,TEAL,controls)
	var speed_panel:=_panel(Vector2.ZERO,Vector2(350,112),Color(1,0.98,0.92,0.98));_right(speed_panel,-374,0);_bottom(speed_panel,-374,-136)
	_cab_icon(_button(t("go").replace("▶","").strip_edges(),Vector2(10,10),Vector2(155,55),_go,TEAL,speed_panel),"go",28)
	var brake_button:=_button(t("brake").replace("■","").strip_edges(),Vector2(178,10),Vector2(160,55),_brake,CORAL,speed_panel)
	brake_button.name="CabBrake"
	brake_model=Cab.attach(brake_button,"brake",load("res://assets/cab/brake.svg"),38)
	var lever_button:=_button("",Vector2(10,70),Vector2(50,36),_cycle_speed,Color("e5eadc"),speed_panel)
	lever_button.name="CabLever"
	lever_button.tooltip_text=t("speed_lever")
	lever_model=Cab.attach(lever_button,"lever",load("res://assets/cab/lever.svg"),31)
	_label(t("speed"),Vector2(65,68),Vector2(94,35),13,INK,speed_panel)
	speed_slider=HSlider.new();speed_panel.add_child(speed_slider);speed_slider.position=Vector2(160,76);speed_slider.size=Vector2(176,25);speed_slider.min_value=0.7;speed_slider.max_value=5;speed_slider.step=0.1;speed_slider.value=speed_setting
	speed_slider.position=_flow_position(Vector2(160,76),Vector2(176,25),speed_panel)
	speed_slider.tooltip_text=t("speed")
	speed_slider.value_changed.connect(func(v): speed_setting=v;if_running_speed(v);_update_lever())
	_update_lever()
	var camera_panel:=_panel(Vector2.ZERO,Vector2(64,250),Color(1,0.98,0.92,0.92));_right(camera_panel,-88,212)
	_cab_icon(_button("",Vector2(6,6),Vector2(52,52),func(): zoom=clampf(zoom-2,14,40),CREAM,camera_panel),"zoom_in",30)
	_cab_icon(_button("",Vector2(6,65),Vector2(52,52),func(): zoom=clampf(zoom+2,14,40),CREAM,camera_panel),"zoom_out",30)
	_button("◉",Vector2(6,124),Vector2(52,52),func(): camera_follow=not camera_follow;_toast(t("follow") if camera_follow else t("orbit")),CREAM,camera_panel)
	_button("↻",Vector2(6,183),Vector2(52,52),func(): _start_level(level_index),CREAM,camera_panel)
	var cam_help:=_label(t("touch_hint") if OS.has_feature("android") else t("camera_hint"),Vector2(30,0),Vector2(1120,30),13,INK);_bottom(cam_help,30,-33)
	drag_label=_label("",Vector2.ZERO,Vector2(120,62),34,TEAL);drag_label.visible=false;drag_label.z_index=20
	_update_selection();_update_status()

func _switch_controls(controls: Control, cargo: bool) -> void:
	var left:=518 if cargo else 195
	switch_label=_label(t("switch_to"),Vector2(left,7),Vector2(290,30),16,TEAL,controls)
	for i in range(3):
		var color:=Color(["e59585","a3c7e8","a5cc9e"][i])
		_button(str(i+1),Vector2(left+i*96,40),Vector2(88,56),func(): _set_switch(i),color,controls)
	_update_switch_label()

func _update_switch_label() -> void:
	if is_instance_valid(switch_label):
		switch_label.text=t("switch_value") % (switch_index+1)

func _set_switch(index: int) -> void:
	if world_id!=5 or index<0 or index>=city_routes.size() or won:
		return
	if speed>0.12 or desired_speed>0 or travelled>3.0:
		_toast(t("switch_locked"))
		return
	switch_index=index
	route=city_routes[index]
	art.outdoors.update_switch(index)
	_create_goal(Network.levels()[level_index].station)
	_update_train(0)
	_update_switch_label()

func _ring_bell() -> void:
	if screen!="game" or modal!=null:return
	bell_count+=1
	_play_sound("bell")
	if is_instance_valid(bell_model):
		if bell_tween!=null and bell_tween.is_valid():bell_tween.kill()
		bell_model.rotation.z=0.0
		bell_tween=create_tween().bind_node(bell_model)
		for angle in [0.30,-0.24,0.15,-0.08,0.0]:
			bell_tween.tween_property(bell_model,"rotation:z",angle,0.075)

func _update_lever() -> void:
	if is_instance_valid(lever_model):
		lever_model.rotation.z=lerpf(0.43,-0.43,inverse_lerp(0.7,5.0,speed_setting))

func _cycle_speed() -> void:
	if not is_instance_valid(speed_slider):return
	var next:=1.4 if speed_setting>=4.4 else (2.8 if speed_setting<2.7 else 4.8)
	speed_slider.value=next

func if_running_speed(v: float) -> void:
	if desired_speed>0:desired_speed=v

func _select_piece(kind: String) -> void:
	selected_kind=kind;_update_selection()

func _begin_drag(kind: String) -> void:
	selected_kind=kind;dragging_piece=true;_update_selection()
	if is_instance_valid(drag_model):drag_model.queue_free()
	drag_model=art.model("train-kit","railroad-straight" if kind!="curve" else "railroad-corner-small")
	var mat:=StandardMaterial3D.new();mat.albedo_color=Color(1,0.76,0.28,0.7);mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	_override(drag_model,mat)

func _rotate_piece() -> void:
	selected_yaw=posmod(selected_yaw+90,360);_update_selection();_play_sound("snap")

func _update_selection() -> void:
	if is_instance_valid(selected_label):
		selected_label.text=t(selected_kind)+"  ·  "+str(selected_yaw)+"°"
	for key in selected_buttons:
		if is_instance_valid(selected_buttons[key]):
			selected_buttons[key].add_theme_stylebox_override("normal",_cab_style(Color("f1cc82") if key==selected_kind else Color("e7eedb")))

func _update_status() -> void:
	if not is_instance_valid(status_label):return
	var mode: String=Network.levels()[level_index].mode
	status_label.text=(t("ready") if missing.is_empty() else t("missing") % missing.size()) if mode=="build" else t("loaded") % cargo_count if mode=="cargo" else t("station_hint")

func _place_piece(idx: int) -> bool:
	if not missing.has(idx) or won:return false
	var piece: Dictionary=route.pieces[idx]
	if selected_kind!=piece.kind:_toast(t("wrong_piece"));return false
	var expected := posmod(roundi(rad_to_deg(piece.yaw)),360)
	var modulo := 360 if piece.kind=="curve" else 180
	if posmod(selected_yaw,modulo)!=posmod(expected,modulo):_toast(t("wrong_rotation"));return false
	missing.erase(idx);track_nodes[idx].visible=true;ghost_nodes[idx].visible=false
	undo_stack.append(idx);redo_stack.clear();_play_sound("snap");_toast(t("snap"));_update_status()
	return true

func _undo() -> void:
	if undo_stack.is_empty() or speed>0.01:return
	var idx=undo_stack.pop_back();missing.append(idx);redo_stack.append(idx)
	track_nodes[idx].visible=false;ghost_nodes[idx].visible=true;_update_status()

func _redo() -> void:
	if redo_stack.is_empty() or speed>0.01:return
	var idx=redo_stack.pop_back();missing.erase(idx);undo_stack.append(idx)
	track_nodes[idx].visible=true;ghost_nodes[idx].visible=false;_update_status()

func _hint() -> void:
	hint_used=true
	if not missing.is_empty():
		var idx: int=missing[0]
		selected_kind=route.pieces[idx].kind;selected_yaw=posmod(roundi(rad_to_deg(route.pieces[idx].yaw)),360)
		_update_selection();_toast(t("hint_text"))
	else:_toast(t("ready"))

func _load_cargo(count: int) -> void:
	if speed>0.1:return
	cargo_count=count;loaded_count=count
	for i in range(parcel_nodes.size()):parcel_nodes[i].visible=i<count
	_play_sound("snap");_update_status()

func _go() -> void:
	if won:return
	if route.get("open",false) and distance>=float(route.length)-0.66:
		_toast(t("line_end"))
		return
	if not missing.is_empty():_toast(t("missing") % missing.size());return
	var data: Dictionary=Network.levels()[level_index]
	if data.mode=="cargo" and cargo_count!=data.number:_toast(t("cargo_hint"));return
	brake_requested=false;desired_speed=speed_setting;_play_sound("whistle")

func _brake() -> void:
	if is_instance_valid(brake_model):
		if brake_tween!=null and brake_tween.is_valid():brake_tween.kill()
		brake_model.position.y=0.0
		brake_tween=create_tween().bind_node(brake_model)
		brake_tween.tween_property(brake_model,"position:y",-0.15,0.075)
		brake_tween.tween_property(brake_model,"position:y",0.0,0.16)
	brake_requested=true
	desired_speed=0
	var data: Dictionary=Network.levels()[level_index]
	if data.mode!="build" and _circular_distance(distance,goal_distance)>1.65:_toast(t("brake_outside"))

func _circular_distance(a: float,b: float) -> float:
	if b<0:
		return INF
	var diff:=absf(a-b)
	return diff if route.get("open",false) else minf(diff,route.length-diff)

func _update_train(delta: float) -> void:
	if route.is_empty():return
	var curve: Curve3D=route.curve
	for i in range(cars.size()):
		var d:=_curve_offset(distance-i*2.85)
		var front:=curve.sample_baked(_curve_offset(d+0.57),true)
		var back:=curve.sample_baked(_curve_offset(d-0.57),true)
		cars[i].position=(front+back)*0.5+Vector3(0,0.035,0)
		var tangent: Vector3=(front-back).normalized()
		cars[i].basis=Basis.looking_at(tangent,Vector3.UP,true)
	for wheel in wheels:wheel.rotate_x(speed*delta/0.265)

func _curve_offset(value: float) -> float:
	return clampf(value,0.0,route.length) if route.get("open",false) else fposmod(value,route.length)

func _update_camera(delta: float) -> void:
	var focus := cars[0].position if camera_follow and not cars.is_empty() else Vector3(3.5 if language=="ar" else -3.5,0.0,0) if screen=="menu" else (Vector3(0,1.2,-1.7) if world_id>=2 else Vector3.ZERO)
	target=target.lerp(focus,1.0-exp(-delta*3))
	var offset:=Vector3(sin(yaw)*cos(pitch),sin(pitch),cos(yaw)*cos(pitch))*42
	camera.position=target+offset
	camera.look_at(target,Vector3.UP)
	camera.size=lerpf(camera.size,zoom,1.0-exp(-delta*6))

func _process(delta: float) -> void:
	timer+=delta
	if art==null:return
	art.animate(timer,delta,low_graphics)
	if world_id>=2:
		art.outdoors.animate(delta,low_graphics,cars[0].position)
	if modal==null:
		speed=move_toward(speed,desired_speed,delta*(4.8 if desired_speed==0 else 1.8))
		var move:=speed*delta
		if screen=="game" and not missing.is_empty():move=0;speed=0;desired_speed=0
		if route.get("open",false):
			var end: float=route.length-0.65
			var before:=distance
			distance=minf(distance+move,end)
			travelled+=distance-before
			if distance>=end and speed>0.0:
				speed=0
				desired_speed=0
				if screen=="game" and Network.levels()[level_index].mode!="build" and (goal_distance<0 or not brake_requested):
					_toast(t("wrong_station") if goal_distance<0 else t("line_end"))
		else:
			distance=fposmod(distance+move,route.length)
			travelled+=move
		_update_train(delta)
		if screen=="game" and not won:
			var data: Dictionary=Network.levels()[level_index]
			var build_finished: bool=distance>=float(route.get("end_stop",INF)) if route.get("open",false) else travelled>=route.length
			if data.mode=="build" and missing.is_empty() and build_finished:
				_win()
			elif data.mode!="build" and travelled>2 and speed<0.08 and desired_speed==0 and _circular_distance(distance,goal_distance)<1.65:
				var stopped_by_player: bool=brake_requested or not route.get("open",false)
				if stopped_by_player and (data.mode=="drive" or cargo_count==data.number):
					_win()
	_update_camera(delta)
	for idx in ghost_nodes:
		if is_instance_valid(ghost_nodes[idx]):
			var base_y: float=0.0 if route.get("open",false) else route.pieces[idx].pos.y+1.03
			ghost_nodes[idx].position.y=base_y+sin(timer*2.5)*0.035
	if is_instance_valid(goal_ring):
		var pulse:=1.12+sin(timer*2)*0.08;goal_ring.scale=Vector3(pulse,0.3,pulse)
	if train_choice==0 and speed>0.2 and not low_graphics:
		steam_clock+=delta
		if steam_clock>0.23:_puff();steam_clock=0
	for i in range(steam.size()-1,-1,-1):
		var p: Dictionary=steam[i];p.life-=delta;p.node.position.y+=delta*0.7;p.node.position.x+=delta*0.15;p.node.scale+=Vector3.ONE*delta*0.35
		if p.life<=0:p.node.visible=false;steam.remove_at(i)
	for i in range(confetti.size()-1,-1,-1):
		var p: Dictionary=confetti[i];p.life-=delta;p.velocity.y-=delta*3;p.node.position+=p.velocity*delta;p.node.rotate_z(delta*2)
		if p.life<=0:p.node.queue_free();confetti.remove_at(i)
	if is_instance_valid(drag_label):
		drag_label.visible=false
	if is_instance_valid(drag_model):
		drag_model.visible=dragging_piece
		if dragging_piece:
			var center:=Vector3(-2+sqrt(2),0,sqrt(2)) if selected_kind=="curve" else Vector3(0,0,2)
			var nearest:=_nearest_gap(pointer,125.0)
			var position:=_world_point(pointer)
			if nearest>=0:
				position=route.pieces[nearest].center
			drag_model.position=position-center.rotated(Vector3.UP,deg_to_rad(selected_yaw))+Vector3(0,1.4,0)
			drag_model.rotation.y=deg_to_rad(selected_yaw)
	if sound_volume>0 and speed>0.25:
		sound_clock+=delta
		if sound_clock>maxf(0.12,0.5/speed):_play_train_tick();sound_clock=0
	if OS.has_feature("web"):
		web_clock+=delta
		if web_clock>0.2:
			web_clock=0
			var locations: Array=[]
			for idx in missing:
				var p: Vector2=camera.unproject_position(route.pieces[idx].center)
				locations.append({"index":idx,"kind":route.pieces[idx].kind,"yaw":posmod(roundi(rad_to_deg(route.pieces[idx].yaw)),360),"x":p.x,"y":p.y})
			var state := {"screen":screen,"level":level_index,"world":world_id,"missing":locations,"distance":distance,"speed":speed,"travelled":travelled,"goal":goal_distance,"won":won,"language":language,"stars":stars,"modal":is_instance_valid(modal),"selected_yaw":selected_yaw,"cargo":cargo_count,"low_graphics":low_graphics,"branch":switch_index,"length":route.length,"end_stop":route.get("end_stop",-1)}
			JavaScriptBridge.eval("window.railvitoSnapshot="+JSON.stringify(state)+";")

func _puff() -> void:
	for n in steam_pool:
		if not n.visible:
			n.visible=true;n.position=cars[0].position+Vector3(0,1.8,0);n.scale=Vector3.ONE
			steam.append({"node":n,"life":1.3});return

func _win() -> void:
	if won:return
	won=true;desired_speed=0;speed=0
	var earned:=2 if hint_used else 3
	stars[level_index]=maxi(stars[level_index],earned);_save()
	_play_sound("win")
	for i in range(32):
		var plane:=PlaneMesh.new();plane.size=Vector2(0.16,0.22)
		var n: MeshInstance3D=art.mesh_node(plane,art.material(["edb052","df8062","77b6a4","a6d0df"][i%4]),cars[0].position+Vector3(0,2.4,0))
		confetti.append({"node":n,"velocity":Vector3(sin(i*2.4)*2.3,2.2+(i%4)*0.3,cos(i*2.4)*2.3),"life":3.2})
	var p:=_open_modal(Vector2(540,405))
	var title:=_label(t("success"),Vector2(20,20),Vector2(500,65),36,TEAL,p);title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var st:=_label("★".repeat(earned),Vector2(20,90),Vector2(500,70),52,GOLD,p);st.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var desc:=_label(t("completed"),Vector2(22,166),Vector2(496,50),20,INK,p);desc.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	_button(t("next") if level_index<stars.size()-1 else t("worlds"),Vector2(36,240),Vector2(468,62),func(): _start_level(level_index+1) if level_index<stars.size()-1 else _show_worlds(),CORAL,p)
	_button(t("again"),Vector2(36,320),Vector2(468,52),func(): _start_level(level_index),Color("e5ebd5"),p)

func _world_point(pos: Vector2) -> Vector3:
	var ray_origin:=camera.project_ray_origin(pos)
	var ray_dir:=camera.project_ray_normal(pos)
	var hit=Plane(Vector3.UP,0.14).intersects_ray(ray_origin,ray_dir)
	return hit if hit!=null else Vector3(999,999,999)

func _nearest_gap(pos: Vector2, radius: float) -> int:
	var best:=-1
	var limit:=radius
	for idx in missing:
		var point: Vector3=route.pieces[idx].center
		if camera.is_position_behind(point):
			continue
		var distance_to_point:=camera.unproject_position(point).distance_to(pos)
		if distance_to_point<limit:
			limit=distance_to_point
			best=idx
	return best

func _drop_at(pos: Vector2) -> void:
	if screen!="game" or modal!=null or won:return
	if pos.y>get_viewport().get_visible_rect().size.y-145:return
	var best:=_nearest_gap(pos,65.0)
	if best>=0:_place_piece(best)

func _input(event: InputEvent) -> void:
	if event is InputEventMouse:
		pointer=event.position
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and not event.pressed:
		if dragging_piece:
			dragging_piece=false;_drop_at(event.position)
		orbiting=false
	if event is InputEventScreenTouch:
		if event.pressed:touches[event.index]=event.position
		else:touches.erase(event.index);pinch_previous=0
	if event is InputEventScreenDrag:
		touches[event.index]=event.position
		if touches.size()==2 and modal==null:
			var points:=touches.values();var gap: float=points[0].distance_to(points[1])
			if pinch_previous>0:zoom=clampf(zoom-(gap-pinch_previous)*0.035,14,40)
			pinch_previous=gap;orbiting=false
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode==KEY_ESCAPE:
			if modal!=null:_close_modal()
			elif screen=="game":_show_levels(world_id)
			else:_show_menu()
		if screen=="game" and modal==null:
			if event.keycode==KEY_R:_rotate_piece()
			if event.keycode==KEY_SPACE:_go() if desired_speed==0 else _brake()
			if event.keycode==KEY_Z and event.ctrl_pressed:_undo()
			if event.keycode==KEY_Y and event.ctrl_pressed:_redo()

func _unhandled_input(event: InputEvent) -> void:
	if modal!=null:return
	if event is InputEventMouseButton:
		if event.button_index==MOUSE_BUTTON_WHEEL_UP:zoom=clampf(zoom-1.4,14,40)
		if event.button_index==MOUSE_BUTTON_WHEEL_DOWN:zoom=clampf(zoom+1.4,14,40)
		if event.button_index==MOUSE_BUTTON_LEFT and event.pressed and touches.size()<2:
			_drop_at(event.position);orbiting=true
	if event is InputEventMouseMotion and orbiting and not dragging_piece and touches.size()<2:
		yaw-=event.relative.x*0.006;pitch=clampf(pitch+event.relative.y*0.003,0.35,1.15);camera_follow=false

func _toast(text: String) -> void:
	if not is_instance_valid(ui):return
	if is_instance_valid(toast_label):toast_label.queue_free()
	toast_label=_label(text,Vector2(378,110),Vector2(790,62),19,TEAL)
	toast_label.add_theme_stylebox_override("normal",_box(CREAM,16))
	var current: WeakRef=weakref(toast_label)
	get_tree().create_timer(3.0).timeout.connect(func():
		var label=current.get_ref()
		if label!=null:label.queue_free())

func _open_modal(size: Vector2) -> Panel:
	_close_modal()
	modal=Control.new();ui.add_child(modal);modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade:=ColorRect.new();modal.add_child(shade);shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);shade.color=Color(0.10,0.20,0.21,0.38)
	var p:=_panel(Vector2.ZERO,size,CREAM,modal)
	p.anchor_left=0.5;p.anchor_right=0.5;p.anchor_top=0.5;p.anchor_bottom=0.5
	p.offset_left=-size.x/2;p.offset_right=size.x/2;p.offset_top=-size.y/2;p.offset_bottom=size.y/2
	return p

func _close_modal() -> void:
	if is_instance_valid(modal):modal.queue_free()
	modal=null

func _settings() -> void:
	var p:=_open_modal(Vector2(700,565))
	_label(t("settings"),Vector2(28,8),Vector2(640,60),32,TEAL,p)
	_label(t("language"),Vector2(28,78),Vector2(640,36),20,INK,p)
	for i in range(3):
		var lang: String=["en_GB","ar","pt_BR"][i]
		_button(["English (UK)","العربية","Português (BR)"][i],Vector2(26+i*224,124),Vector2(216,58),func(): _change_language(lang),GOLD if language==lang else Color("e5ebd8"),p)
	_label(t("sound"),Vector2(28,206),Vector2(280,42),21,INK,p)
	var slider:=HSlider.new();p.add_child(slider);slider.position=Vector2(320,218);slider.size=Vector2(338,36);slider.min_value=0;slider.max_value=1;slider.step=0.05;slider.value=sound_volume
	slider.position=_flow_position(Vector2(320,218),Vector2(338,36),p)
	slider.value_changed.connect(func(v):sound_volume=v;_set_audio_volume();_save())
	_label(t("graphics"),Vector2(28,276),Vector2(260,50),21,INK,p)
	_button(t("low") if low_graphics else t("high"),Vector2(320,276),Vector2(338,52),func(): low_graphics=not low_graphics;art.sun.shadow_enabled=not low_graphics;_save();_settings(),Color("e5ebd8"),p)
	_label(t("night") if evening else t("day"),Vector2(28,350),Vector2(260,50),21,INK,p)
	_button(t("day") if evening else t("night"),Vector2(320,350),Vector2(338,52),func(): _set_evening(not evening);_save();_settings(),Color("e5ebd8"),p)
	_button(t("close"),Vector2(28,454),Vector2(630,64),func():_save();_close_modal(),TEAL,p)

func _change_language(lang: String) -> void:
	language=lang;_save()
	# Rebuild the current screen, preserving the active puzzle and train state.
	if screen=="game":_game_ui()
	elif screen=="levels":_show_levels(world_id)
	elif screen=="worlds":_show_worlds()
	else:_show_menu()
	_settings()

func _set_evening(value: bool) -> void:
	evening=value
	if art!=null:
		art.sun.light_energy=0.58 if evening else 0.85
		art.sun.light_color=Color("ffd1a2") if evening else Color("fff2d5")
		art.sun.rotation_degrees.x=-22 if evening else -48

func _train_menu() -> void:
	var p:=_open_modal(Vector2(670,360))
	_label(t("train"),Vector2(26,15),Vector2(610,60),30,TEAL,p)
	for i in range(3):
		_button(t(["steam","diesel","electric"][i]),Vector2(26,95+i*67),Vector2(615,57),func(): train_choice=i;_create_train();_save();_close_modal();_toast(t("train_selected")),[CORAL,GOLD,TEAL][i],p)

func _parents_gate() -> void:
	var p:=_open_modal(Vector2(620,315))
	_label(t("gate"),Vector2(26,14),Vector2(565,60),30,TEAL,p)
	var a:=randi_range(6,9);var b:=randi_range(6,9);var answer:=a*b
	_label(t("gate_question") % [a,b],Vector2(26,86),Vector2(565,60),25,INK,p)
	var answers: Array=[answer,answer+7,answer-9];answers.shuffle()
	for i in range(3):
		var value: int=answers[i]
		_button(str(value),Vector2(28+i*195,168),Vector2(176,62),func(): _parents_area() if value==answer else _toast(t("gate_retry")),Color("e6d6ac"),p)
	_button(t("close"),Vector2(28,245),Vector2(565,48),_close_modal,CREAM,p)

func _parents_area() -> void:
	var p:=_open_modal(Vector2(720,485))
	_label(t("gate"),Vector2(26,12),Vector2(665,58),30,TEAL,p)
	var text:=_label(t("parent_note")+"\n\n"+t("all_progress") % [stars.size()-stars.count(0),stars.size()],Vector2(28,80),Vector2(660,137),20,INK,p);text.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	_button(t("privacy"),Vector2(28,240),Vector2(320,58),_privacy,Color("e4ebd8"),p)
	_button(t("about"),Vector2(365,240),Vector2(325,58),_about,Color("e4ebd8"),p)
	_button(t("close"),Vector2(28,362),Vector2(662,62),_close_modal,TEAL,p)

func _text_modal(title: String, text: String) -> void:
	var p:=_open_modal(Vector2(740,500))
	_label(title,Vector2(26,12),Vector2(680,60),30,TEAL,p)
	var body:=_label(text,Vector2(28,85),Vector2(680,280),21,INK,p);body.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;body.vertical_alignment=VERTICAL_ALIGNMENT_TOP
	_button(t("close"),Vector2(28,399),Vector2(680,62),_close_modal,TEAL,p)

func _privacy() -> void:_text_modal(t("privacy"),t("privacy_body"))
func _about() -> void:
	var p:=_open_modal(Vector2(760,560))
	_label(t("about"),Vector2(26,10),Vector2(710,60),30,TEAL,p)
	var scroller:=ScrollContainer.new();p.add_child(scroller);scroller.position=Vector2(28,85);scroller.size=Vector2(704,355)
	var body:=RichTextLabel.new();scroller.add_child(body);body.custom_minimum_size=Vector2(680,0);body.fit_content=true;body.scroll_active=false
	body.add_theme_color_override("default_color",INK);body.add_theme_font_size_override("normal_font_size",17)
	body.text=t("credits")+"\n\nGodot Engine — MIT License\n\n"+Engine.get_license_text()
	for license_path in ["res://licenses/font-fonts-dejavu-core.txt","res://licenses/font-fonts-noto-core.txt"]:
		body.text+="\n\n"+FileAccess.get_file_as_string(license_path)
	_button(t("close"),Vector2(28,468),Vector2(704,62),_close_modal,TEAL,p)
func _help() -> void:_text_modal(t("help_title"),t("help_body"))

func _set_audio_volume() -> void:
	if is_instance_valid(tone):tone.volume_db=linear_to_db(maxf(sound_volume*0.6,0.0001))
	if is_instance_valid(train_sound):train_sound.volume_db=linear_to_db(maxf(sound_volume*0.10,0.0001))

func _play_sound(name: String) -> void:
	if sound_volume<=0 or DisplayServer.get_name()=="headless":return
	var path:="res://assets/audio/"+name+".wav"
	if ResourceLoader.exists(path):tone.stream=load(path);tone.play()

func _play_train_tick() -> void:
	if DisplayServer.get_name()=="headless":return
	if not train_sound.playing:
		train_sound.stream=load("res://assets/audio/chuff.wav");train_sound.pitch_scale=0.75+speed*0.10;train_sound.play()

func _save() -> void:
	var c:=ConfigFile.new()
	c.set_value("state","version",1);c.set_value("state","stars",stars)
	c.set_value("settings","language",language);c.set_value("settings","train",train_choice)
	c.set_value("settings","volume",sound_volume);c.set_value("settings","low_graphics",low_graphics);c.set_value("settings","evening",evening)
	last_save_error=c.save(SAVE_PATH)
	if last_save_error!=OK:push_warning("Progress could not be saved: %s" % last_save_error)

func _load_save() -> void:
	var c:=ConfigFile.new()
	if c.load(SAVE_PATH)!=OK:return
	var saved=c.get_value("state","stars",[])
	if saved is Array:
		for i in range(mini(saved.size(),stars.size())):
			stars[i]=clampi(int(saved[i]),0,3)
	var lang=str(c.get_value("settings","language","en_GB"))
	language=lang if lang in ["en_GB","ar","pt_BR"] else "en_GB"
	train_choice=clampi(int(c.get_value("settings","train",0)),0,2)
	sound_volume=clampf(float(c.get_value("settings","volume",0.65)),0,1)
	low_graphics=bool(c.get_value("settings","low_graphics",false));evening=bool(c.get_value("settings","evening",false))

func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_PAUSED:
		_save();desired_speed=0;speed=0
	if what==NOTIFICATION_WM_GO_BACK_REQUEST:
		if modal!=null:_close_modal()
		elif screen=="game":_show_levels(world_id)
		elif screen=="levels":_show_worlds()
		elif screen=="worlds":_show_menu()
		else:_save();get_tree().quit()

func _self_test() -> void:
	var passed:=0
	var original_stars:=stars.duplicate()
	for id in range(2):
		var r: Dictionary=Network.create(id)
		assert(r.closure_error<0.0001,"Track loop must close")
		assert(absf(r.length-(40+4*PI))<0.06,"Arc length must match geometry")
		for j in range(200):
			var p: Vector3=r.curve.sample_baked(r.length*j/200.0)
			assert(p.is_finite(),"Train sample must be finite")
		passed+=1
	for i in range(10):
		_start_level(i)
		assert(route.pieces.size()==14)
		for idx in missing.duplicate():
			selected_kind=route.pieces[idx].kind;selected_yaw=posmod(roundi(rad_to_deg(route.pieces[idx].yaw)),360)
			assert(_place_piece(idx),"Authored rail must be placeable")
		assert(missing.is_empty(),"Puzzle must be solvable")
		if not undo_stack.is_empty():
			_undo();assert(missing.size()==1);_redo();assert(missing.is_empty())
		if Network.levels()[i].mode=="cargo":
			_load_cargo(Network.levels()[i].number);assert(cargo_count==Network.levels()[i].number)
		var mode: String=Network.levels()[i].mode
		if mode=="build":
			travelled=route.length-0.4;_process(0.001);assert(not won,"A partial lap must not complete a mission")
			travelled=route.length+0.01;_process(0.001);assert(won,"A connected complete lap must win")
		else:
			travelled=5;distance=goal_distance;speed=2;desired_speed=2;_process(0.001)
			assert(not won,"Passing a station at speed must not win")
			speed=0;desired_speed=0;distance=fposmod(goal_distance+3,route.length);_process(0.001)
			assert(not won,"Stopping outside the station must not win")
			distance=goal_distance
			if mode=="cargo":
				cargo_count=0;_process(0.001);assert(not won,"Wrong cargo count must not win")
				_load_cargo(Network.levels()[i].number)
			_process(0.001);assert(won,"A correct stop and cargo must complete the mission")
		passed+=1
	for k in Words.EN:
		if k in ["zoom_in","zoom_out","number"]:continue
		assert(Words.AR.has(k),"Arabic key missing: "+k)
		assert(Words.PT.has(k),"Portuguese key missing: "+k)
	assert(cars.size()==3 and wheels.size()>0,"Original train and wheel nodes loaded")
	stars[0]=3;_save();assert(last_save_error==OK);stars[0]=0;_load_save();assert(stars[0]==3);stars=original_stars;_save()
	print("RAILVITO_SELF_TEST_OK: %s authored worlds/levels; connected paths, placement, undo/redo, cargo, station speed/position, completion, localization and save reload" % passed)
	await get_tree().process_frame
	get_tree().quit(0)
