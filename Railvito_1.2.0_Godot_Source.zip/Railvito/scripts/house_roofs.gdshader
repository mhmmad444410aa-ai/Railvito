shader_type spatial;
uniform sampler2D palette : source_color, filter_nearest;
uniform vec4 roof_tint : source_color;

void fragment() {
	vec3 colour = texture(palette, UV).rgb;
	float is_roof = step(colour.r + 0.095, colour.g) * step(colour.b + 0.025, colour.g);
	ALBEDO = mix(colour, roof_tint.rgb * (0.50 + colour.g * 0.72), is_roof);
	ROUGHNESS = 0.82;
}
