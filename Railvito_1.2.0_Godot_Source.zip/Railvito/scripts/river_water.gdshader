shader_type spatial;
render_mode cull_disabled;

void fragment() {
	float wave = sin(UV.y * 74.0 - TIME * 2.5 + sin(UV.x * 13.0 + TIME * 0.8));
	float ripple = smoothstep(0.72, 1.0, wave) * 0.12;
	float foam = smoothstep(0.39, 0.50, abs(UV.x - 0.5)) * 0.20;
	ALBEDO = vec3(0.09, 0.47, 0.57) + vec3(0.65, 0.94, 0.95) * (ripple + foam);
	ROUGHNESS = 0.23;
	SPECULAR = 0.5;
}
