extends RefCounted
## Original low-poly models, rendered in a small independent HUD viewport.
## No downloaded reference artwork is redistributed.

static func _part(parent: Node3D, mesh: Mesh, color: Color, pos: Vector3) -> MeshInstance3D:
	var part := MeshInstance3D.new()
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.45
	part.mesh = mesh
	part.material_override = material
	parent.add_child(part)
	part.position = pos
	return part

static func _cylinder(parent: Node3D, top: float, bottom: float, height: float, y: float, color: Color) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = top
	mesh.bottom_radius = bottom
	mesh.height = height
	mesh.radial_segments = 16
	return _part(parent, mesh, color, Vector3(0, y, 0))

static func _box(parent: Node3D, dimensions: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	return _part(parent, mesh, color, pos)

static func attach(button: Button, kind: String, fallback: Texture2D, icon_width := 42) -> Node3D:
	button.icon = fallback
	button.add_theme_constant_override("icon_max_width", icon_width)
	button.expand_icon = true
	# Do not allocate rendering resources in headless CI.
	if DisplayServer.get_name() == "headless":
		return null
	var viewport := SubViewport.new()
	viewport.size = Vector2i(96, 96)
	viewport.transparent_bg = true
	viewport.own_world_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
	button.add_child(viewport)
	var stage := Node3D.new()
	viewport.add_child(stage)
	var pivot := Node3D.new()
	stage.add_child(pivot)
	var dark := Color("304451")
	match kind:
		"bell":
			_cylinder(pivot, 0.53, 0.74, 0.18, -0.53, Color("e6ac45"))
			_cylinder(pivot, 0.30, 0.56, 0.74, -0.10, Color("f2bf55"))
			_cylinder(pivot, 0.23, 0.34, 0.16, 0.35, Color("ffd47a"))
			var ring := TorusMesh.new()
			ring.inner_radius = 0.11; ring.outer_radius = 0.25
			var handle := _part(pivot, ring, Color("f6ca64"), Vector3(0, 0.56, 0))
			handle.rotation.x = PI/2
			var clapper := SphereMesh.new()
			clapper.radius = 0.15; clapper.height = 0.30
			_part(pivot, clapper, Color("976323"), Vector3(0, -0.67, 0))
		"brake":
			_box(stage, Vector3(1.55, 0.25, 1.45), Vector3(0, -0.57, 0), dark)
			_cylinder(pivot, 0.65, 0.72, 0.17, -0.34, Color("772f34"))
			_cylinder(pivot, 0.57, 0.65, 0.55, 0.0, Color("e84d49"))
			_cylinder(pivot, 0.52, 0.57, 0.10, 0.32, Color("ff6f59"))
		"lever":
			_box(stage, Vector3(1.40, 0.25, 1.25), Vector3(0, -0.62, 0), dark)
			_cylinder(stage, 0.33, 0.47, 0.26, -0.40, Color("748c96"))
			pivot.position.y = -0.36
			_box(pivot, Vector3(0.18, 0.80, 0.18), Vector3(0, 0.40, 0), Color("c2d3d5"))
			_box(pivot, Vector3(0.44, 0.24, 0.36), Vector3(0, 0.86, 0), Color("e7ad51"))
	var camera := Camera3D.new()
	stage.add_child(camera)
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 2.25
	camera.position = Vector3(2.5, 2.0, 4.0)
	camera.look_at(Vector3.ZERO)
	camera.current = true
	var key := DirectionalLight3D.new()
	stage.add_child(key)
	key.rotation_degrees = Vector3(-40, -35, 0)
	key.light_energy = 1.4
	var fill := DirectionalLight3D.new()
	stage.add_child(fill)
	fill.rotation_degrees = Vector3(-20, 145, 0)
	fill.light_energy = 0.7
	button.icon = viewport.get_texture()
	return pivot
