extends RefCounted
## The diorama uses original downloaded Kenney GLB files. All decorations stay
## outside the rail corridor; the custom board, water and clouds are original.

const Outdoors = preload("res://scripts/adventure_art.gd")

var outdoors: Outdoors
var root: Node3D
var trees: Array[Node3D] = []
var clouds: Array[Node3D] = []
var stations: Array = []
var water_material: ShaderMaterial
var sun: DirectionalLight3D
var world_id := 0
var cache := {}

func model(pack: String, asset: String, pos := Vector3.ZERO, scl := Vector3.ONE, yaw := 0.0) -> Node3D:
	var path := "res://assets/%s/%s.glb" % [pack, asset]
	if not cache.has(path):
		cache[path] = load(path)
	var obj: Node3D = cache[path].instantiate()
	_matte_materials(obj)
	root.add_child(obj)
	obj.position = pos
	obj.scale = scl
	obj.rotation.y = yaw
	return obj

func _matte_materials(n: Node) -> void:
	if n is MeshInstance3D:
		for i in range(n.mesh.get_surface_count()):
			var m = n.mesh.surface_get_material(i)
			if m is StandardMaterial3D:
				m.metallic=0.0
				m.roughness=0.78
				m.metallic_specular=0.22
	for c in n.get_children():_matte_materials(c)

func material(hex: String, roughness := 0.8) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(hex)
	m.roughness = roughness
	return m

func mesh_node(mesh: Mesh, mat: Material, pos: Vector3, parent: Node3D = null) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = mesh
	n.material_override = mat
	(parent if parent else root).add_child(n)
	n.position = pos
	return n

func rounded_board(width: float, depth: float, height: float, radius: float, mat: Material, y: float) -> MeshInstance3D:
	var edge: Array[Vector2] = []
	for c in range(4):
		var center := Vector2((width / 2.0 - radius) * (1 if c in [0,3] else -1), (depth / 2.0 - radius) * (1 if c in [0,1] else -1))
		for k in range(13):
			var angle := c * PI / 2.0 + k * PI / 24.0
			edge.append(center + Vector2(cos(angle),sin(angle)) * radius)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(edge.size()):
		var a := edge[i]
		var b := edge[(i + 1) % edge.size()]
		st.set_normal(Vector3.UP)
		for p in [Vector3.ZERO,Vector3(a.x,0,a.y),Vector3(b.x,0,b.y)]: st.add_vertex(p)
		var normal := Vector3((a.x+b.x)*0.5,0,(a.y+b.y)*0.5).normalized()
		st.set_normal(normal)
		for p in [Vector3(a.x,0,a.y),Vector3(b.x,0,b.y),Vector3(b.x,-height,b.y),Vector3(a.x,0,a.y),Vector3(b.x,-height,b.y),Vector3(a.x,-height,a.y)]: st.add_vertex(p)
	return mesh_node(st.commit(),mat,Vector3(0,y,0))

func _build_horizon(id: int) -> void:
	# An independent low-profile scenery ring. No collision shapes or input targets.
	var horizon := Node3D.new()
	horizon.name="ScenicHorizon"
	root.add_child(horizon)
	var rng := RandomNumberGenerator.new()
	rng.seed=8173+id
	var hill := SphereMesh.new()
	hill.radius=1.0;hill.height=2.0;hill.radial_segments=16;hill.rings=8
	var palette := ["a7cba0","83b58e","b5d4a5"]
	if id==3:palette=["d5e5ec","a8c5d6","e6f1f4"]
	elif id==4:palette=["e6f1ff","d5e7f8","f0f7ff"]
	elif id==5:palette=["a6c5a2","90b5a1","c0d5ad"]
	var mats: Array[StandardMaterial3D]=[]
	for hex in palette:mats.append(material(hex))
	for i in range(20):
		var angle:=TAU*float(i)/20.0
		var radius:=19.0 if id<2 else (26.0 if id==4 else 35.0)
		var p:=Vector3(cos(angle)*radius,-1.55 if id<2 else 0.10,sin(angle)*radius)
		if id==4:p.y=-7.0
		var obj:=mesh_node(hill,mats[i%3],p,horizon)
		obj.scale=Vector3(rng.randf_range(4.0,6.2),rng.randf_range(1.1,2.5),rng.randf_range(3.5,5.4))
		if id==4:obj.scale.y=0.85
		obj.rotation.y=angle
		obj.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# A second layer, intentionally lower and wider to frame rather than hide play.
	for i in range(12):
		var angle:=TAU*(float(i)+0.5)/12.0
		var radius:=31.0 if id<2 else 46.0
		var p:=Vector3(cos(angle)*radius,-2.2 if id!=4 else -8.5,sin(angle)*radius)
		var obj:=mesh_node(hill,mats[(i+1)%3],p,horizon)
		obj.scale=Vector3(8.0,2.8 if id!=4 else 1.2,6.0)
		obj.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func build(parent: Node3D, id: int, layout: Dictionary = {}) -> void:
	root = parent
	world_id = id
	trees.clear(); clouds.clear(); stations.clear()
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("83bbec" if id >= 2 else "9cd8db")
	sky_mat.sky_horizon_color = Color("e4eef8" if id >= 2 else "edf3db")
	sky_mat.ground_horizon_color = sky_mat.sky_horizon_color
	sky_mat.ground_bottom_color = Color("bccde8" if id == 4 else "c7c5a1")
	sky.sky_material = sky_mat
	e.sky = sky
	if id==4:
		e.background_mode=Environment.BG_COLOR
		e.background_color=Color("9ac5ec")
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color("fff1d7")
	e.ambient_light_energy = 0.45
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	e.tonemap_exposure = 0.65
	e.tonemap_white = 6.0
	env.environment = e
	root.add_child(env)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48,-35,0)
	sun.light_color = Color("fff2d5")
	sun.light_energy = 0.85
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 75
	sun.shadow_bias = 0.04
	root.add_child(sun)
	_build_horizon(id)
	if id >= 2:
		outdoors = Outdoors.new()
		outdoors.build(self,layout)
		return
	var ground := PlaneMesh.new()
	ground.size = Vector2(200,200)
	mesh_node(ground,material("d6dfcb"),Vector3(0,-1.12,0))
	var w := 25.5 if id == 0 else 24.0
	var d := 22.0 if id == 0 else 26.0
	rounded_board(w,d,0.9,2.5,material("bd9166"),-0.1)
	rounded_board(w-0.12,d-0.12,0.18,2.45,material("f5dfad"),0.02)
	rounded_board(w-0.6,d-0.6,0.05,2.2,material("78a56e" if id == 0 else "6aa891"),0.07)
	_make_river(id)
	var rng := RandomNumberGenerator.new()
	rng.seed = 773 + id
	# Fixed composition, with a clear silhouette and an unobstructed rail corridor.
	var positions := [Vector2(-10,-7.5),Vector2(-9.4,-5.3),Vector2(-10.8,-2),Vector2(-10,1.5),Vector2(-9.6,6.8),Vector2(-8.1,8.8),Vector2(-5,8.7),Vector2(4.7,8.7),Vector2(9.4,7.0),Vector2(10.2,4),Vector2(10.4,-1),Vector2(9.5,-6.4),Vector2(6,-8.5),Vector2(-3,-8.7),Vector2(-6.5,-8.8),Vector2(3.7,2.0),Vector2(-3.5,-1.0),Vector2(-4.5,-3.0)]
	for i in range(positions.size()):
		var p: Vector2 = positions[i]
		if id == 1:
			p = Vector2(p.x * 0.94,p.y * 1.15)
			if p.y < -7 and p.x < 0: continue
		var name: String = ["tree_oak","tree_oak_dark","tree_small"][i % 3] if id == 0 else ["tree_pineRoundA","tree_pineRoundB","tree_pineTallA"][i % 3]
		var s := rng.randf_range(1.7,2.5)
		var obj := model("nature-kit",name,Vector3(p.x,0.13,p.y),Vector3.ONE*s,rng.randf_range(0,TAU))
		trees.append(obj)
	for i in range(44):
		var p := Vector3(rng.randf_range(-10.7,10.7),0.17,rng.randf_range(-9.1,9.1))
		if id == 0 and (abs(abs(p.x)-8) < 1.1 or abs(abs(p.z)-6) < 1.0): continue
		if id == 1 and (abs(abs(p.x)-6) < 1.1 or abs(abs(p.z)-8) < 1.0): continue
		if abs(p.x-0.6*sin(p.z*0.4)) < 1.8: continue
		var name: String = ["flower_redA","flower_purpleA","flower_yellowA","plant_bushSmall"][i % 4]
		model("nature-kit",name,p,Vector3.ONE*rng.randf_range(0.8,1.6),rng.randf_range(0,TAU))
	if id == 0:
		_make_castle(Vector3(-4.6,0.15,-2.2),0.85)
		for z in [-2.8,-0.3]:
			model("castle-kit","tower-square-arch",Vector3(8,0.14,z),Vector3(2.6,2.6,0.45))
		model("castle-kit","tower-square-top-roof",Vector3(8,2.60,-1.55),Vector3(2.8,0.65,3.2))
		model("nature-kit","rock_largeB",Vector3(9.7,0.1,-3),Vector3(3,3,3))
	else:
		model("nature-kit","rock_largeB",Vector3(-8.4,0.14,-10.2),Vector3(4,9,3),0.6)
		model("nature-kit","cliff_waterfall_rock",Vector3(-6,0.14,-8.5),Vector3(3.6,3.5,3.5))
		model("nature-kit","rock_largeB",Vector3(-3.7,0.14,-10.3),Vector3(3.5,6,3),-0.8)
		_make_waterfall(Vector3(-6,0.18,-6.55),3.4)
		_make_castle(Vector3(2.3,0.15,-2.5),0.7)
	for z in [-6.0,6.0] if id == 0 else [-8.0,8.0]:
		model("nature-kit","bridge_stone",Vector3(0,-0.3,z),Vector3(3.8,1.0,1.9),PI/2)
	_make_station(Vector3(-2.3,0.13,8.0 if id == 0 else 10.0),Color("e67d60"),0)
	_make_station(Vector3(3.3,0.13,-8.0 if id == 0 else -10.0),Color("60a8b9"),1)
	_make_station(Vector3(-10 if id == 0 else -8,0.13,1.5),Color("6ba986"),2)
	for i in range(5):
		var cloud := Node3D.new()
		root.add_child(cloud)
		cloud.position = Vector3(-15+i*7,7.8+rng.randf()*1.5,-11.5+rng.randf()*4)
		for k in range(4):
			var sphere := SphereMesh.new()
			sphere.radial_segments = 12; sphere.rings = 6
			sphere.radius = 0.6+0.25*(k%2);sphere.height=sphere.radius*1.5
			var n := mesh_node(sphere,material("fff9e8"),Vector3(k*0.65,0.15*(k%2),0),cloud)
			n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		clouds.append(cloud)

func _make_castle(pos: Vector3, s: float) -> void:
	for dx in [-1.0,1.0]:
		for dy in [0.0,0.95]:
			model("castle-kit","tower-square-base" if dy == 0 else "tower-square-mid-windows",pos+Vector3(dx*1.8*s,dy*s,0),Vector3.ONE*s)
		model("castle-kit","tower-square-roof",pos+Vector3(dx*1.8*s,1.9*s,0),Vector3.ONE*s)
	model("castle-kit","wall-doorway",pos,Vector3(2.6*s,1.2*s,s))
	model("castle-kit","flag",pos+Vector3(1.8*s,3.8*s,0),Vector3.ONE*s)

func _make_station(pos: Vector3, color: Color, index: int) -> void:
	var n := Node3D.new()
	root.add_child(n);n.position=pos
	var plat := CylinderMesh.new()
	plat.top_radius=1.7;plat.bottom_radius=1.7;plat.height=0.2;plat.radial_segments=32
	mesh_node(plat,material("f9e7bc"),Vector3(0,0,0),n)
	# Real modular architecture, combined into a station with a coloured canopy.
	var base := model("castle-kit","tower-square-mid-windows",pos+Vector3(0,0.1,0),Vector3(1.8,0.9,1.2))
	var roof := model("castle-kit","tower-square-top-roof",pos+Vector3(0,0.95,0),Vector3(1.9,0.7,1.3))
	_tint_roof(roof,color)
	var label := Label3D.new()
	label.text = str(index+1) if index>=0 else "▶"
	label.font_size=100;label.pixel_size=0.01
	label.modulate=Color("fff9df");label.outline_modulate=color.darkened(0.25);label.outline_size=16
	label.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	n.add_child(label);label.position=Vector3(0,2.5,0)
	stations.append({"node":n,"pos":pos,"color":color,"label":label})

func _tint_roof(n: Node, color: Color) -> void:
	if n is MeshInstance3D:
		n.material_override=material(color.to_html())
	for c in n.get_children(): _tint_roof(c,color)

func _make_river(id: int) -> void:
	var shader := Shader.new()
	shader.code = "shader_type spatial; render_mode cull_disabled; uniform vec4 tint: source_color = vec4(0.22,0.69,0.72,1.0); void vertex(){ VERTEX.y += sin(VERTEX.x*3.0+TIME*1.3)*0.018+cos(VERTEX.z*2.1+TIME)*0.014; } void fragment(){ float wave=sin(UV.y*70.0-TIME*2.0+sin(UV.x*18.0))*0.5+0.5; ALBEDO=tint.rgb+vec3(0.10)*pow(wave,9.0); ROUGHNESS=0.27; METALLIC=0.12; }"
	water_material=ShaderMaterial.new();water_material.shader=shader
	var st := SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var bound:=10.7 if id==0 else 12.7
	for i in range(64):
		var z0 := -bound+i*(bound*2.0/64.0)
		var z1 := z0+bound*2.0/64.0
		var x0 := sin(z0*0.42)*0.5
		var x1 := sin(z1*0.42)*0.5
		var width := 1.3 if id == 0 else 1.6
		for v in [Vector3(x0-width,0,z0),Vector3(x0+width,0,z0),Vector3(x1+width,0,z1),Vector3(x0-width,0,z0),Vector3(x1+width,0,z1),Vector3(x1-width,0,z1)]:
			st.set_normal(Vector3.UP);st.set_uv(Vector2((v.x+2)/4.0,(v.z+13)/26.0));st.add_vertex(v)
	mesh_node(st.commit(),water_material,Vector3(0,0.10,0))
	_make_waterfall(Vector3(sin(bound*0.42)*0.5,-0.93,bound-0.02),1.04)
	for i in range(12):
		var z := -9.0+i*1.6
		model("nature-kit","stone_smallA" if i%2==0 else "stone_smallB",Vector3(sin(z*0.42)*0.5+(-1.5 if i%2==0 else 1.5),0.12,z),Vector3.ONE*1.4)

func _make_waterfall(pos: Vector3, height: float) -> void:
	var plane := PlaneMesh.new();plane.size=Vector2(1.7,height)
	var fall := mesh_node(plane,water_material,pos+Vector3(0,height/2,0))
	fall.rotation.x=PI/2
	if height>1.5:
		var splash := CylinderMesh.new();splash.top_radius=1.1;splash.bottom_radius=1.1;splash.height=0.03;splash.radial_segments=32
		mesh_node(splash,material("d8f3e7"),pos+Vector3(0,0.03,0.3))

func animate(time: float, delta: float, low: bool) -> void:
	if not low:
		for i in range(trees.size()): trees[i].rotation.z=sin(time*0.9+i)*0.015
	for i in range(clouds.size()):
		clouds[i].position.x += delta*(0.12+i*0.025)
		if clouds[i].position.x > 19: clouds[i].position.x=-19
