extends RefCounted
## Outdoor scenery and geometry for the four new routes.

var builder_ref: WeakRef
var art:
	get:
		return builder_ref.get_ref()
var route: Dictionary
var style_id: int
var terrain_samples: Array[Vector3] = []
var barriers: Array[Node3D] = []
var crossing := Vector3(0,0.18,5)
var switch_lamps: Array[MeshInstance3D] = []
var snow: GPUParticles3D
var palette_cache: Dictionary = {}

func build(builder, layout: Dictionary) -> void:
	builder_ref = weakref(builder)
	route = layout
	style_id = route.world
	var curve: Curve3D = route.curve
	for i in range(ceilf(route.length)+1):
		terrain_samples.append(curve.sample_baked(float(i)))
	match style_id:
		2: _valley()
		3: _summit()
		4: _sky()
		5: _city()
	_stations()

func track(piece: Dictionary, line: Dictionary, ghost: Material = null) -> Node3D:
	var node := Node3D.new()
	art.root.add_child(node)
	var curve: Curve3D = line.curve
	var from: float = piece.from
	var interval: float = piece.length
	var ballast: Material = ghost if ghost else art.material("82918c" if style_id == 3 else "a0846d")
	var steel: Material = ghost if ghost else art.material("c0d5d8",0.34)
	var timber: Material = ghost if ghost else art.material("8c5a39")
	_strip(node,curve,from,interval,-0.65,0.65,-0.09,0.09,ballast)
	for side in [-1.0,1.0]:
		_strip(node,curve,from,interval,side*0.30-0.045,side*0.30+0.045,-0.022,0.10,steel)
	var sleeper_mesh := SurfaceTool.new()
	sleeper_mesh.begin(Mesh.PRIMITIVE_TRIANGLES)
	var count := maxi(1,roundi(interval/0.42))
	for i in range(count):
		var d := from+interval*(i+0.5)/count
		var a := curve.sample_baked(d-0.068,true)
		var b := curve.sample_baked(d+0.068,true)
		var right := (b-a).cross(Vector3.UP).normalized()*0.52
		_quad(sleeper_mesh,a-right,b-right,b+right,a+right,Vector3.UP)
	art.mesh_node(sleeper_mesh.commit(),timber,Vector3(0,-0.035,0),node)
	if piece.kind == "bridge":
		var deck: Material = ghost if ghost else art.material("b98557" if style_id == 4 else "ab9080")
		_strip(node,curve,from,interval,-0.97,0.97,-0.18,0.23,deck)
		for side in [-1.0,1.0]:
			_strip(node,curve,from,interval,side*0.85-0.065,side*0.85+0.065,0.29,0.07,deck)
		if not ghost:
			var p: Vector3 = piece.center
			var lower := _height(p.x,p.z) if style_id != 4 else p.y-2.8
			var heading: Vector3=curve.sample_baked(from+interval*0.7)-curve.sample_baked(from+interval*0.3)
			_bridge_arch(node,p,heading,interval,lower)
	return node

func _bridge_arch(parent: Node3D, center: Vector3, heading: Vector3, width: float, ground: float) -> void:
	var foundation:=center.y-0.12
	if foundation-ground<0.65:
		return
	var support:=Node3D.new()
	parent.add_child(support)
	support.position=Vector3(center.x,foundation,center.z)
	support.rotation.y=atan2(heading.x,heading.z)
	var radius:=width*0.37
	var arch_height:=minf(radius,foundation-ground-0.10)
	var foot:=foundation-ground-arch_height*0.72
	var stone: Material=art.material("b28b6c" if style_id==4 else "a38f83")
	var seam: Material=art.material("99765c" if style_id==4 else "8e7c76")
	for side in [-1.0,1.0]:
		_box(Vector3(0,-foot*0.5-arch_height*0.7,side*(radius+0.2)),Vector3(1.36,foot,0.42),stone,support)
		_box(Vector3(0,-foot-arch_height*0.69,side*(radius+0.2)),Vector3(1.54,0.26,0.56),seam,support)
	var surf:=SurfaceTool.new()
	surf.begin(Mesh.PRIMITIVE_TRIANGLES)
	for k in range(13):
		var a:=PI*k/13.0
		var b:=PI*(k+1)/13.0
		var y0:=sin(a)*arch_height*0.84-arch_height*0.97
		var y1:=sin(b)*arch_height*0.84-arch_height*0.97
		var z0:=cos(a)*radius
		var z1:=cos(b)*radius
		for side in [-0.65,0.65]:
			_quad(surf,Vector3(side,y0,z0),Vector3(side,y1,z1),Vector3(side,0.02,z1),Vector3(side,0.02,z0),Vector3(signf(side),0,0))
		_quad(surf,Vector3(-0.65,y0,z0),Vector3(0.65,y0,z0),Vector3(0.65,y1,z1),Vector3(-0.65,y1,z1),Vector3.DOWN)
	art.mesh_node(surf.commit(),stone,Vector3.ZERO,support)

func _strip(parent: Node3D, curve: Curve3D, start: float, length: float, left: float, right: float, y: float, height: float, mat: Material) -> void:
	var surf := SurfaceTool.new()
	surf.begin(Mesh.PRIMITIVE_TRIANGLES)
	var steps := maxi(2,ceili(length/0.38))
	for i in range(steps):
		var da := start + length*float(i)/steps
		var db := start + length*float(i+1)/steps
		var a := curve.sample_baked(da,true)+Vector3.UP*y
		var b := curve.sample_baked(db,true)+Vector3.UP*y
		var ar := _curve_right(curve,da)
		var br := _curve_right(curve,db)
		var al := a+ar*left
		var bl := b+br*left
		var rr := a+ar*right
		var rb := b+br*right
		_quad(surf,al,bl,rb,rr,Vector3.UP)
		_quad(surf,al,al-Vector3.UP*height,bl-Vector3.UP*height,bl,-ar)
		_quad(surf,rr,rb,rb-Vector3.UP*height,rr-Vector3.UP*height,ar)
	art.mesh_node(surf.commit(),mat,Vector3.ZERO,parent)

func _curve_right(curve: Curve3D, d: float) -> Vector3:
	return (curve.sample_baked(d+0.07)-curve.sample_baked(d-0.07)).cross(Vector3.UP).normalized()

func _quad(surf: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, normal: Vector3) -> void:
	if (c-a).cross(b-a).dot(normal) < 0:
		var swap := b
		b = d
		d = swap
	for vertex in [a,b,c,a,c,d]:
		surf.set_normal(normal)
		surf.add_vertex(vertex)

func _box(pos: Vector3, size: Vector3, mat: Material, parent: Node3D = null) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	return art.mesh_node(mesh,mat,pos,parent)

func _sphere(pos: Vector3, scale: Vector3, mat: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius=1;mesh.height=2;mesh.radial_segments=12;mesh.rings=6
	var n: MeshInstance3D = art.mesh_node(mesh,mat,pos)
	n.scale=scale
	return n

func _closest(x: float,z: float) -> Vector2:
	var best := Vector2(INF,0)
	for p in terrain_samples:
		var d := Vector2(x-p.x,z-p.z).length_squared()
		if d < best.x:
			best=Vector2(d,p.y)
	return Vector2(sqrt(best.x),best.y)

func _river_x(z: float) -> float:
	return sin(z*0.19)*2.2-0.6

func _height(x: float, z: float) -> float:
	if style_id == 5:
		return 0.025
	var near := _closest(x,z)
	if style_id == 2:
		var river := absf(x-_river_x(z))
		var hills := 0.20 + 0.30*sin(x*0.39)*cos(z*0.25) + 4.2*exp(-pow((absf(x)-18.0)/5.5,2.0))
		var land := lerpf(-1.70,hills,smoothstep(1.6,4.4,river))
		return lerpf(near.y-0.17,land,maxf(smoothstep(0.7,4.0,near.x),1.0-smoothstep(2.25,4.5,river)))
	var ridge := clampf((12-z)*0.23,-0.22,6.2)
	ridge += 5.4*exp(-pow((absf(x)-17.0)/6.0,2.0)-pow((z+12)/11.0,2.0))
	ridge += sin(x*0.31+z*0.21)*0.68
	var trestle_cut := 2.1*exp(-pow((z-0.4)/4.5,2.0)-pow(x/9.0,2.0))
	return lerpf(near.y-0.17,ridge,smoothstep(0.65,3.5,near.x))-trestle_cut

func _terrain() -> void:
	var surf := SurfaceTool.new()
	surf.begin(Mesh.PRIMITIVE_TRIANGLES)
	var side := 61
	var step := 1.05
	var data: Array[Vector3] = []
	for zi in range(side):
		for xi in range(side):
			var x := (xi-30)*step
			var z := (zi-30)*step
			data.append(Vector3(x,_height(x,z),z))
	var palette := ["54854f","78a661","577552"] if style_id == 2 else ["e9f1f5","bfd6df","8e9da9"]
	for z in range(side-1):
		for x in range(side-1):
			var at := z*side+x
			for i in [at,at+1,at+side+1,at,at+side+1,at+side]:
				var p := data[i]
				var n := Vector3(_height(p.x-0.16,p.z)-_height(p.x+0.16,p.z),0.32,_height(p.x,p.z-0.16)-_height(p.x,p.z+0.16)).normalized()
				var c := Color(palette[0]).lerp(Color(palette[1]),0.50+0.45*sin(p.x*0.52)*cos(p.z*0.42))
				if n.y < 0.86:
					c=c.lerp(Color(palette[2]),(1-n.y)*0.75)
				surf.set_color(c);surf.set_normal(n);surf.add_vertex(p)
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo=true
	mat.roughness=1
	art.mesh_node(surf.commit(),mat,Vector3.ZERO)

func _plants(snowy: bool) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed=1154+style_id
	for i in range(120):
		var x := rng.randf_range(-23,23)
		var z := rng.randf_range(-23,23)
		if _closest(x,z).x<2.8 or (not snowy and absf(x-_river_x(z))<4.0):
			continue
		var y := _height(x,z)
		if snowy:
			var name: String=["tree-snow-a","tree-snow-b","tree-snow-c"][i%3]
			art.model("holiday-kit",name,Vector3(x,y,z),Vector3.ONE*rng.randf_range(1.1,2.2),rng.randf_range(0,TAU))
		else:
			var name: String=["tree_oak","tree_small","tree_pineRoundA","flower_purpleA","flower_yellowA"][i%5]
			var tree: Node3D = art.model("nature-kit",name,Vector3(x,y+0.07,z),Vector3.ONE*rng.randf_range(1.0,2.45),rng.randf_range(0,TAU))
			if i%5<3:
				art.trees.append(tree)
			_recolour(tree,{"leafsGreen":["538640","60964a","6da454"][i%3],"leafsDark":"3a7854","woodBark":"8f6646","woodBarkDark":"73533c","grass":"619c4a"})

func _valley() -> void:
	_terrain()
	_plants(false)
	var shader := ShaderMaterial.new()
	shader.shader=load("res://scripts/river_water.gdshader")
	var surf := SurfaceTool.new()
	surf.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in range(56):
		var z := -31.0+62.0*i/56
		var end := z+62.0/56
		var a := _river_x(z)
		var b := _river_x(end)
		for p in [Vector3(a-2.8,-0.73,z),Vector3(a+2.8,-0.73,z),Vector3(b+2.8,-0.73,end),Vector3(a-2.8,-0.73,z),Vector3(b+2.8,-0.73,end),Vector3(b-2.8,-0.73,end)]:
			surf.set_uv(Vector2((p.x-_river_x(p.z))/5.6+0.5,(p.z+31)/62))
			surf.set_normal(Vector3.UP);surf.add_vertex(p)
	art.mesh_node(surf.commit(),shader,Vector3.ZERO)
	art.water_material=shader
	var falls_x:=_river_x(-20)
	for side in [-1.0,1.0]:
		for i in range(3):
			var cliff: Node3D=art.model("nature-kit","rock_largeB",Vector3(falls_x+side*(1.0+i*2.2),-0.6,-24+i*0.45),Vector3(4.0,16.0-float(i)*2.0,6.0),i*0.35)
			_recolour(cliff,{"dirt":"80786b","grass":"63864c"})
	art._make_waterfall(Vector3(falls_x,-0.70,-22.9),4.8)
	for spot in [Vector2(-13,6),Vector2(14,8),Vector2(-12,-10),Vector2(12,-10),Vector2(-13,-14),Vector2(14,-14)]:
		if _closest(spot.x,spot.y).x>3.0:
			var house: Node3D=art.model("city-kit-suburban","building-type-b",Vector3(spot.x,_height(spot.x,spot.y)+0.05,spot.y),Vector3.ONE*2.15,PI*0.25)
			_paint_house(house,"b97556")
	for z in [-12.0,-2.0,9.0]:
		for side in [-1.0,1.0]:
			var x: float = _river_x(z)+side*3.45
			var stone: Node3D=art.model("nature-kit","rock_largeB",Vector3(x,_height(x,z),z),Vector3(2.1,2.3,1.6),z)
			_recolour(stone,{"dirt":"7d827a","grass":"a3a899"})

func _summit() -> void:
	_terrain()
	_plants(true)
	for side in [-1.0,1.0]:
		for i in range(5):
			var x: float = side*(15.0+i*1.46)
			var z := -14.5-i*1.6
			var y := _height(x,z)
			var peak: Node3D=art.model("nature-kit","rock_largeB",Vector3(x,y-0.30,z),Vector3(5.0,16.0+1.3*i,5.7),i*0.45)
			_recolour(peak,{"dirt":"788b9c","grass":"eef7fb"})
	for i in [1,5]:
		var p: Vector3 = route.points[i]
		var d: float=route.curve.get_closest_offset(p)
		var heading: Vector3=route.curve.sample_baked(d+0.25)-route.curve.sample_baked(d-0.25)
		var angle:=atan2(heading.x,heading.z)
		art.model("castle-kit","tower-square-arch",p,Vector3(2.7,2.5,1.2),angle)
		_sphere(p+Vector3(0,2.30,0),Vector3(1.45,0.37,0.78),art.material("f1f7fb"))
	snow = GPUParticles3D.new()
	art.root.add_child(snow)
	snow.position=Vector3(0,12,0);snow.amount=128;snow.lifetime=8
	var process := ParticleProcessMaterial.new()
	process.emission_shape=ParticleProcessMaterial.EMISSION_SHAPE_BOX
	process.emission_box_extents=Vector3(21,5,21);process.gravity=Vector3(0,-0.27,0);process.direction=Vector3(0.3,-1,0.05)
	process.initial_velocity_min=0.55;process.initial_velocity_max=1.10
	var flakes := QuadMesh.new();flakes.size=Vector2(0.115,0.115)
	var mat: StandardMaterial3D = art.material("ffffff")
	mat.billboard_mode=BaseMaterial3D.BILLBOARD_ENABLED
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	flakes.material=mat;snow.process_material=process;snow.draw_pass_1=flakes
	snow.visibility_aabb=AABB(Vector3(-28,-20,-28),Vector3(56,30,56))

func _island(center: Vector3, radius: float, depth: float, seed: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed=seed
	var soil := SurfaceTool.new()
	soil.begin(Mesh.PRIMITIVE_TRIANGLES)
	var top := SurfaceTool.new()
	top.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rim: Array[Vector3] = []
	for i in range(24):
		var angle := TAU*i/24
		var r := radius*(0.87+0.14*sin(angle*3+seed)+0.07*rng.randf())
		rim.append(Vector3(cos(angle)*r,-0.16,sin(angle)*r))
	for i in range(rim.size()):
		var a := rim[i]
		var b := rim[(i+1)%rim.size()]
		_quad(top,Vector3.ZERO,a,b,Vector3.ZERO,Vector3.UP)
		var ai := a*0.92+Vector3(0,-depth*0.34,0)
		var bi := b*0.92+Vector3(0,-depth*0.34,0)
		_quad(soil,a,ai,bi,b,(a+b).normalized())
		var base:=Vector3(0,-depth,0)
		_quad(soil,ai,base,bi,ai,(a+b-Vector3.UP*radius).normalized())
	art.mesh_node(top.commit(),art.material("629952"),center)
	art.mesh_node(soil.commit(),art.material("957b72"),center)
	for i in range(12):
		var angle := i*TAU/12+0.31
		var r := radius*rng.randf_range(0.52,0.80)
		var p := center+Vector3(cos(angle)*r,0.02,sin(angle)*r)
		if _closest(p.x,p.z).x<1.8:
			continue
		var name: String=["tree_oak","tree_small","flower_purpleA","flower_redA"][i%4]
		var plant: Node3D=art.model("nature-kit",name,p,Vector3.ONE*rng.randf_range(0.9,1.9),angle)
		_recolour(plant,{"leafsGreen":"5d934d","woodBark":"8f6646","grass":"578e48"})

func _sky() -> void:
	var points: Array = route.points
	var middle: Vector3=points[3].lerp(points[4],0.72)
	var last: Vector3=points[-1].lerp(points[-2],0.30)
	_island(points[0].lerp(points[1],0.38)-Vector3.UP*0.24,7.5,5.3,22)
	_island(middle-Vector3.UP*0.21,6.5,5.6,9)
	_island(last-Vector3.UP*0.2,7.1,5.9,31)
	_island(Vector3(-17,0.3,-8),3.6,3.5,15)
	_island(Vector3(16,-0.8,10),3.3,3.4,17)
	var mist: StandardMaterial3D = art.material("e7f2ff")
	mist.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	for pos in [Vector3(-18,-4,2),Vector3(4,-5,15),Vector3(13,-4,-9),Vector3(-9,-4,-17),Vector3(17,-6,3),Vector3(-15,-7,-15),Vector3(1,-7,-22)]:
		var puff_root:=Node3D.new()
		art.root.add_child(puff_root)
		puff_root.position=pos
		for j in range(5):
			var cloud:=_sphere(Vector3.ZERO,Vector3(1.7+0.3*(j%3),0.75+0.2*(j%3),1.35),mist)
			cloud.reparent(puff_root,false)
			cloud.position=Vector3(j*1.1,0.22*(j%3),0)
			cloud.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		art.clouds.append(puff_root)
	art.water_material=ShaderMaterial.new()
	art.water_material.shader=load("res://scripts/river_water.gdshader")
	art._make_waterfall(middle+Vector3(-0.6,-5.8,5.2),5.65)
	var pavilion: Node3D=art.model("castle-kit","tower-square-top-roof",middle+Vector3(2.6,0.88,2.8),Vector3(1.5,1.2,1.5))
	art._tint_roof(pavilion,Color("d38c8e"))
	for offset in [Vector3(1.98,0.25,2.2),Vector3(3.22,0.25,2.2),Vector3(1.98,0.25,3.38),Vector3(3.22,0.25,3.38)]:
		_box(middle+offset,Vector3(0.13,1.35,0.13),art.material("d9ba88"))

func _city() -> void:
	var ground := PlaneMesh.new()
	ground.size=Vector2(54,48)
	art.mesh_node(ground,art.material("6f985a"),Vector3(0,0.005,0))
	var asphalt: Material=art.material("6f8287")
	var paving: Material=art.material("d8c5a9")
	for z in [-6.0,5.0,13.2]:
		_box(Vector3(0,0.035,z),Vector3(46,0.055,2.3),paving)
		_box(Vector3(0,0.066,z),Vector3(46,0.06,1.82),asphalt)
		for x in range(-21,22,3):
			if _closest(x,z).x>1.3:
				_box(Vector3(x,0.104,z),Vector3(0.85,0.015,0.045),paving)
	for x in [-17.5,17.5]:
		_box(Vector3(x,0.07,0),Vector3(1.8,0.06,39),asphalt)
	var colours := ["efa279","efd790","acc8c3","d0a5b7"]
	var lot := 0
	for x in [-14.5,-11.0,-7.5,7.5,11.0,14.5]:
		for z in [-10.5,-2.2,8.8,16.7]:
			if _closest(x,z).x<2.2 or (z<-6 and absf(x)>9):
				continue
			var name: String = "building-type-"+["a","b","d","f","h","j"][lot%6]
			var house: Node3D=art.model("city-kit-suburban",name,Vector3(x,0.12,z),Vector3.ONE*(1.9+float(lot%3)*0.31),PI*(lot%2))
			_paint_house(house,["b75e4d","587ca2","d4a25c","916d86"][lot%4])
			_box(Vector3(x,0.031,z),Vector3(2.6,0.055,2.55),art.material(colours[lot%4]))
			lot+=1
	for x in [-15,-13,-5,5,13,15]:
		for z in [-15,2,12]:
			if _closest(x,z).x>2:
				art.model("nature-kit","tree_small",Vector3(x,0.12,z),Vector3.ONE*1.55)
	crossing=route.curve.sample_baked(route.curve.get_closest_offset(Vector3(0,0.18,5)))
	for side in [-1,1]:
		var p := crossing+Vector3(side*1.32,0.35,side*0.82)
		var pivot := Node3D.new()
		art.root.add_child(pivot);pivot.position=p;pivot.rotation.y=0 if side==1 else PI
		_box(p+Vector3(0,-0.15,0),Vector3(0.17,0.57,0.17),art.material("647b83"))
		for i in range(7):
			_box(Vector3(-0.14-i*0.23,0,0),Vector3(0.235,0.11,0.14),art.material("dd6155" if i%2==0 else "fff6dc"),pivot)
		barriers.append(pivot)
	for i in range(3):
		var p := Vector3((i-1)*2.85,0.38,-2.2)
		_box(p,Vector3(0.12,0.66,0.13),art.material("525962"))
		switch_lamps.append(_sphere(p+Vector3.UP*0.42,Vector3.ONE*0.23,art.material("dad8cd")))
	update_switch(1)

func _paint_house(node: Node, tint: String) -> void:
	if not palette_cache.has(tint):
		var mat:=ShaderMaterial.new()
		mat.shader=load("res://scripts/house_roofs.gdshader")
		mat.set_shader_parameter("palette",load("res://assets/city-kit-suburban/Textures/colormap.png"))
		mat.set_shader_parameter("roof_tint",Color(tint))
		palette_cache[tint]=mat
	if node is MeshInstance3D:
		node.material_override=palette_cache[tint]
	for child in node.get_children():
		_paint_house(child,tint)

func _recolour(node: Node, colours: Dictionary) -> void:
	if node is MeshInstance3D:
		for i in range(node.mesh.get_surface_count()):
			var source: Material=node.mesh.surface_get_material(i)
			if source and colours.has(source.resource_name):
				var tint: String=colours[source.resource_name]
				if not palette_cache.has(tint):
					palette_cache[tint]=art.material(tint)
				node.set_surface_override_material(i,palette_cache[tint])
	for child in node.get_children():
		_recolour(child,colours)

func _stations() -> void:
	var colors := [Color("da695f"),Color("639ed5"),Color("65a87d")]
	if style_id != 5:
		var start: Vector3=route.points[0]
		art._make_station(start+Vector3(-2,0.01,-1.9),Color("e9b567"),-1)
	for i in range(route.stations.size()):
		var stop: Vector3=route.stations[i]
		var shift := Vector3(2.18,0,0)
		if style_id==5 and i==0:
			shift.x=-2.25
		art._make_station(stop+shift,colors[i],i)

func update_switch(branch: int) -> void:
	for i in range(switch_lamps.size()):
		var mat: StandardMaterial3D = art.material(["dc735f","5faff0","66c998"][i] if i==branch else "6a7677")
		mat.emission_enabled=i==branch
		mat.emission=mat.albedo_color
		switch_lamps[i].material_override=mat

func animate(delta: float, low: bool, train_position: Vector3) -> void:
	if snow:
		snow.emitting=not low
	for arm in barriers:
		var angle := 0.0 if train_position.distance_to(crossing)<4.0 else -1.24
		arm.rotation.z=lerpf(arm.rotation.z,angle,1.0-exp(-delta*5.0))
