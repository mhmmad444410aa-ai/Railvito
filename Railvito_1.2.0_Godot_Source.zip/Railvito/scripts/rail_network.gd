extends RefCounted
## Authored modular loop. Geometry and vehicle movement share these exact samples.
## Distances are arc lengths: carriages never integrate their own physics.

static func create(world_id: int) -> Dictionary:
	var horizontal := 3 if world_id == 0 else 2
	var vertical := 2 if world_id == 0 else 3
	var start := Vector3(horizontal * 2.0 + 2.0, 0.12, -vertical * 2.0)
	var point := start
	var yaw := 0.0
	var pieces: Array = []
	var curve := Curve3D.new()
	curve.bake_interval = 0.035
	var total := 0.0
	for side in range(4):
		var count := vertical if side % 2 == 0 else horizontal
		for _i in range(count):
			var samples: Array[Vector3] = []
			for k in range(21):
				samples.append(point + Vector3(0, 0, k * 0.2).rotated(Vector3.UP, yaw))
			pieces.append({"kind":"straight", "pos":point, "yaw":yaw, "center":samples[10], "from":total, "length":4.0})
			for p in samples:
				if curve.point_count == 0 or curve.get_point_position(curve.point_count - 1).distance_to(p) > 0.001:
					curve.add_point(p)
			point = samples[-1]
			total += 4.0
		var samples: Array[Vector3] = []
		for k in range(33):
			var a := k * PI / 64.0
			samples.append(point + Vector3(-2.0 + cos(a) * 2.0, 0, sin(a) * 2.0).rotated(Vector3.UP, yaw))
		pieces.append({"kind":"curve", "pos":point, "yaw":yaw, "center":samples[16], "from":total, "length":PI})
		for p in samples:
			if curve.get_point_position(curve.point_count - 1).distance_to(p) > 0.001:
				curve.add_point(p)
		point = samples[-1]
		total += PI
		yaw -= PI / 2.0
	return {"curve":curve, "pieces":pieces, "length":curve.get_baked_length(), "start":start, "closure_error":point.distance_to(start)}

const Adventures = preload("res://scripts/adventure_routes.gd")
const WORLD_NAMES := ["wood","water","river_world","snow_world","sky_world","city_world"]

static func for_level(data: Dictionary, branch := 1) -> Dictionary:
	if data.world < 2:
		return create(data.world)
	return Adventures.create(data.world, data.variant, branch)

static func world_levels(id: int) -> Array:
	return levels().filter(func(level): return level.world == id)

static func levels() -> Array:
	return [
		{"id":0,"world":0,"title":"first_tracks","mode":"build","missing":[3,9],"station":0,"number":1},
		{"id":1,"world":0,"title":"garden_bend","mode":"build","missing":[2,5,10],"station":0,"number":1},
		{"id":2,"world":0,"title":"gentle_stop","mode":"drive","missing":[],"station":0,"number":1},
		{"id":3,"world":0,"title":"red_parcel","mode":"cargo","missing":[],"station":0,"number":2},
		{"id":4,"world":0,"title":"bridge_loop","mode":"build","missing":[1,2,4,8,12],"station":0,"number":1},
		{"id":5,"world":1,"title":"waterfall_way","mode":"build","missing":[3,6,11],"station":1,"number":1},
		{"id":6,"world":1,"title":"blue_station","mode":"drive","missing":[],"station":1,"number":1},
		{"id":7,"world":1,"title":"count_and_carry","mode":"cargo","missing":[],"station":1,"number":3},
		{"id":8,"world":1,"title":"winding_rails","mode":"build","missing":[0,3,5,8,10,13],"station":1,"number":1},
		{"id":9,"world":1,"title":"green_delivery","mode":"cargo","missing":[],"station":2,"number":4},
		{"id":10,"world":2,"variant":0,"title":"river_bridge","mode":"build","station":0,"number":1},
		{"id":11,"world":2,"variant":1,"title":"mill_delivery","mode":"cargo","station":0,"number":2},
		{"id":12,"world":3,"variant":0,"title":"snow_climb","mode":"drive","station":0,"number":1},
		{"id":13,"world":3,"variant":1,"title":"snow_viaduct","mode":"build","station":0,"number":1},
		{"id":14,"world":4,"variant":0,"title":"sky_bridge","mode":"build","station":0,"number":1},
		{"id":15,"world":4,"variant":1,"title":"sky_delivery","mode":"cargo","station":0,"number":3},
		{"id":16,"world":5,"variant":0,"title":"city_red","mode":"cargo","station":0,"number":2},
		{"id":17,"world":5,"variant":1,"title":"city_green","mode":"drive","station":2,"number":1}
	]
