extends RefCounted
## Each row describes a distinct journey. Control point indices identify spans
## with a bridge deck, and the same baked curve drives art, snapping and vehicles.

const VALLEY := [
	[Vector3(-10,0.22,15), Vector3(-10,0.22,7), Vector3(-7,0.50,2), Vector3(1,0.83,-1), Vector3(7,0.85,-5), Vector3(8,1.2,-11), Vector3(4,1.3,-17)],
	[Vector3(11,0.22,15), Vector3(11,0.22,7), Vector3(8,0.6,3), Vector3(0,0.96,1), Vector3(-6,0.92,-3), Vector3(-9,1.0,-9), Vector3(-4,1.06,-17)],
]
const SUMMIT := [
	[Vector3(-12,0.22,15), Vector3(-12,0.4,7), Vector3(-8,1.8,3), Vector3(-1,3.1,1), Vector3(7,4.4,-2), Vector3(11,5.6,-7), Vector3(8,6.4,-12), Vector3(0,6.7,-16)],
	[Vector3(11,0.22,15), Vector3(11,0.4,7), Vector3(8,1.7,1), Vector3(1,3.2,-2), Vector3(-6,4.7,-5), Vector3(-11,5.7,-9), Vector3(-7,6.4,-14), Vector3(0,6.8,-17)],
]
const SKY := [
	[Vector3(-9,1.2,15), Vector3(-9,1.2,7), Vector3(-6,1.55,2), Vector3(-1,2.5,0), Vector3(5,2.65,-2), Vector3(10,3.6,-6), Vector3(9,4.4,-12), Vector3(5,4.4,-17)],
	[Vector3(-9,1.2,15), Vector3(-9,1.2,7), Vector3(-6,1.55,2), Vector3(-1,2.5,0), Vector3(4,2.5,-1), Vector3(2,3.0,-7), Vector3(-2,3.9,-11), Vector3(-6,4.4,-17)],
]
const CITY_EXIT := [
	[Vector3(-5,0.18,-2), Vector3(-10,0.18,-7), Vector3(-12,0.18,-15)],
	[Vector3(0,0.18,-3), Vector3(0,0.18,-9), Vector3(0,0.18,-17)],
	[Vector3(5,0.18,-2), Vector3(10,0.18,-7), Vector3(12,0.18,-15)],
]

static func create(world: int, variant: int, branch := 1) -> Dictionary:
	var points: Array
	var bridge_segments: Array = []
	match world:
		2:
			points = VALLEY[variant]
			bridge_segments = [2,3]
		3:
			points = SUMMIT[variant]
			bridge_segments = [2,3] if variant == 0 else [3,4]
		4:
			points = SKY[variant]
			bridge_segments = [1,2,4,5] if variant == 0 else [1,2,5,6]
		5:
			var lead := [Vector3(0,0.18,16), Vector3(0,0.18,7), Vector3(0,0.18,2)]
			if variant == 1:
				lead = [Vector3(7,0.18,17), Vector3(4,0.18,10), Vector3(0,0.18,4), Vector3(0,0.18,2)]
			points = lead + CITY_EXIT[branch]
		_:
			return {}
	var curve := Curve3D.new()
	curve.bake_interval = 0.09
	for i in range(points.size()):
		var incoming: Vector3 = points[i] - points[maxi(0,i-1)]
		var outgoing: Vector3 = points[mini(i+1,points.size()-1)] - points[i]
		var tangent := (incoming.normalized()+outgoing.normalized()).normalized()
		if world == 5 and points[i] == Vector3(0,0.18,2):
			tangent = Vector3.FORWARD
		var in_handle := -tangent * incoming.length() * 0.31
		var out_handle := tangent * outgoing.length() * 0.31
		curve.add_point(points[i],in_handle,out_handle)
	var pieces: Array = []
	var length := curve.get_baked_length()
	for i in range(points.size()-1):
		var from := curve.get_closest_offset(points[i])
		var until := curve.get_closest_offset(points[i+1])
		var count := maxi(1,roundi((until-from)/3.8))
		for j in range(count):
			var start := lerpf(from,until,float(j)/count)
			var end := lerpf(from,until,float(j+1)/count)
			var a := curve.sample_baked(start)
			var b := curve.sample_baked(end)
			var middle := curve.sample_baked((start+end)*0.5)
			var heading := b-a
			var angle := 90 * roundi(rad_to_deg(atan2(heading.x,heading.z))/90.0)
			var curved := middle.distance_to((a+b)*0.5) > 0.18
			var kind := "bridge" if i in bridge_segments else ("curve" if curved else "straight")
			pieces.append({"kind":kind,"pos":a,"yaw":deg_to_rad(angle),"center":middle,"from":start,"length":end-start,"segment":i})
	var end_stop := length - 1.45
	var stations: Array = [curve.sample_baked(end_stop)]
	if world == 5:
		stations = [CITY_EXIT[0][-1],CITY_EXIT[1][-1],CITY_EXIT[2][-1]]
	return {"curve":curve,"pieces":pieces,"length":length,"start":points[0],
		"open":true,"spawn":7.1,"end_stop":end_stop,"branch":branch,"stations":stations,
		"variant":variant,"world":world,"points":points}

static func gaps(route: Dictionary, bridge_only: bool) -> Array:
	var options: Array = []
	for i in range(route.pieces.size()):
		var piece: Dictionary = route.pieces[i]
		if piece.from > route.spawn+1.1 and piece.center.z > -13.5:
			if not bridge_only or piece.kind == "bridge":
				options.append(i)
	if options.size() < 2:
		return options
	return [options[0],options[options.size()/2]]
